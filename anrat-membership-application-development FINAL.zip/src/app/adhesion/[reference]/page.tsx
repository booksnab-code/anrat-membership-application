import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { memberships, type Membership } from "@/db/schema";
import { AnratLogo } from "@/components/AnratLogo";
import { Icon } from "@/components/Icons";
import { PrintButton } from "@/components/PrintButton";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";
import {
  ASSOCIATION,
  STATUS_LABELS,
  formatDateFr,
  formatDateTimeFr,
  maskNumber,
  wilayaLabel,
} from "@/lib/constants";
import { isReferenceFormat, normalizeReference } from "@/lib/references";

export const dynamic = "force-dynamic";

async function getApplication(reference: string): Promise<Membership | null> {
  try {
    const [row] = await db
      .select()
      .from(memberships)
      .where(eq(memberships.reference, reference))
      .limit(1);
    return row ?? null;
  } catch {
    return null;
  }
}

const STATUS_STYLES: Record<string, { badge: string; banner: string; icon: "clock" | "checkCircle" | "alert" }> = {
  en_attente: {
    badge: "text-amber-700",
    banner: "from-at-navy via-at-blue to-at-cyan",
    icon: "clock",
  },
  validee: {
    badge: "text-at-green",
    banner: "from-at-green via-at-green to-at-navy",
    icon: "checkCircle",
  },
  rejetee: {
    badge: "text-at-red",
    banner: "from-slate-700 via-slate-800 to-at-navy",
    icon: "alert",
  },
};

export default async function ReceiptPage({ params }: { params: Promise<{ reference: string }> }) {
  const { reference } = await params;
  const normalized = normalizeReference(decodeURIComponent(reference));
  if (!isReferenceFormat(normalized)) notFound();

  const application = await getApplication(normalized);
  if (!application) notFound();

  const style = STATUS_STYLES[application.status] ?? STATUS_STYLES.en_attente;
  const timeline = [
    { label: "Demande reçue", done: true },
    {
      label: "Examen par l'association",
      done: application.status === "validee" || application.status === "rejetee",
    },
    {
      label: application.status === "rejetee" ? "Dossier à compléter" : "Carte d'adhésion éditée",
      done: application.status === "validee",
    },
  ];

  const details: Array<{ section: string; items: Array<[string, string]> }> = [
    {
      section: "I — Informations personnelles",
      items: [
        ["Nom", application.lastName],
        ["Prénom", application.firstName],
        ["Date de naissance", formatDateFr(application.birthDate)],
        ["Wilaya de résidence", wilayaLabel(application.wilaya)],
        ["Rhésus sanguin", application.bloodType],
      ],
    },
    {
      section: "II — Informations de retraite & santé",
      items: [
        ["Date de départ à la retraite", formatDateFr(application.retirementDate)],
        ["Numéro de sécurité sociale", maskNumber(application.socialSecurityNumber)],
        ["Numéro CNR", maskNumber(application.cnrNumber)],
      ],
    },
    {
      section: "III — Contact personnel & pièces jointes",
      items: [
        ["Numéro mobile", maskNumber(application.mobile, 4)],
        ["Adresse e-mail", application.email],
        ["Pièce jointe", application.attachmentName || "Aucune"],
      ],
    },
  ];

  return (
    <>
      <SiteHeader active="suivi" />

      <main className="mx-auto max-w-4xl px-4 py-8 sm:px-6 sm:py-10">
        <div className="no-print mb-5 flex flex-wrap items-center justify-between gap-3">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-semibold text-slate-600 transition hover:text-at-blue"
          >
            <Icon name="arrowLeft" className="h-4 w-4" />
            Retour au formulaire
          </Link>
          <div className="flex flex-wrap items-center gap-2">
            <PrintButton label="Imprimer mon récapitulatif" />
            <a
              href={`mailto:${ASSOCIATION.email}?subject=${encodeURIComponent(
                `Suivi de ma demande ${application.reference}`,
              )}`}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold text-slate-600 transition hover:border-at-blue/40 hover:text-at-blue"
            >
              <Icon name="mail" className="h-4 w-4" />
              Contacter l&apos;ANRAT
            </a>
          </div>
        </div>

        <section className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-card">
          <div className={`no-print relative bg-gradient-to-br ${style.banner} px-6 py-7 text-white`}>
            <div className="grid-pattern pointer-events-none absolute inset-0 opacity-50" aria-hidden="true" />
            <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/15 ring-1 ring-white/30">
                  <Icon name={style.icon} className="h-6 w-6" strokeWidth={1.9} />
                </span>
                <div>
                  <p className="text-[0.62rem] font-bold uppercase tracking-[0.18em] text-white/70">
                    ANRAT · Suivi de demande
                  </p>
                  <h1 className="mt-1 text-xl font-extrabold tracking-tight sm:text-2xl">
                    {application.status === "validee"
                      ? "Votre adhésion est validée"
                      : application.status === "rejetee"
                        ? "Votre dossier nécessite une attention"
                        : "Votre demande est bien enregistrée"}
                  </h1>
                  <p className="mt-1 text-sm text-white/80">
                    Déposée le {formatDateTimeFr(application.createdAt)} · Référence{" "}
                    <span className="font-mono font-semibold">{application.reference}</span>
                  </p>
                </div>
              </div>
              <span
                className={`inline-flex w-fit items-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-xs font-bold ${style.badge}`}
              >
                <Icon name="shield" className="h-3.5 w-3.5" />
                {STATUS_LABELS[application.status] ?? application.status}
              </span>
            </div>
          </div>

          <div className="no-print border-b border-slate-100 px-6 py-5">
            <ol className="flex flex-col gap-3 sm:flex-row sm:items-center">
              {timeline.map((step, index) => (
                <li key={step.label} className="flex flex-1 items-center gap-2.5">
                  <span
                    className={`grid h-7 w-7 shrink-0 place-items-center rounded-full text-[0.7rem] font-bold ${
                      step.done
                        ? "bg-at-green text-white"
                        : "border border-slate-200 bg-white text-slate-400"
                    }`}
                  >
                    {step.done ? <Icon name="check" className="h-3.5 w-3.5" /> : index + 1}
                  </span>
                  <span
                    className={`text-xs font-semibold ${step.done ? "text-at-navy" : "text-slate-400"}`}
                  >
                    {step.label}
                  </span>
                </li>
              ))}
            </ol>
          </div>

          <div id="print-sheet" className="p-6 sm:p-8">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-2 border-b-2 border-at-navy pb-3">
              <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-at-green">
                {ASSOCIATION.longName}
              </p>
              <p className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-at-navy">
                Récapitulatif de demande d&apos;adhésion — {STATUS_LABELS[application.status] ?? application.status}
              </p>
            </div>

            <div className="flex items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3">
                <AnratLogo className="h-14 w-14" />
                <div>
                  <p className="text-sm font-extrabold tracking-wide text-at-navy">ANRAT</p>
                  <p className="text-[0.68rem] leading-snug text-at-muted">{ASSOCIATION.longName}</p>
                  <p className="text-[0.62rem] font-semibold text-at-green">{ASSOCIATION.longNameAr}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[0.6rem] uppercase tracking-[0.12em] text-at-muted">Référence</p>
                <p className="font-mono text-sm font-bold text-at-navy">{application.reference}</p>
                <p className="mt-1 text-[0.65rem] text-at-muted">
                  Édité le {formatDateFr(new Date())}
                </p>
              </div>
            </div>

            <div className="mt-5 space-y-5">
              {details.map((group) => (
                <section key={group.section} className="print-card rounded-xl border border-slate-200 p-4">
                  <h2 className="border-b border-slate-100 pb-2 text-xs font-bold uppercase tracking-[0.1em] text-at-blue">
                    {group.section}
                  </h2>
                  <dl className="mt-3 grid gap-x-8 gap-y-2 sm:grid-cols-2">
                    {group.items.map(([label, value]) => (
                      <div key={label} className="flex justify-between gap-3 border-b border-dashed border-slate-100 pb-1.5">
                        <dt className="text-xs text-at-muted">{label}</dt>
                        <dd className="text-right text-xs font-semibold text-at-navy">{value || "—"}</dd>
                      </div>
                    ))}
                  </dl>
                </section>
              ))}
            </div>

            <div className="mt-5 rounded-xl bg-slate-50 p-4 text-[0.72rem] leading-relaxed text-slate-600">
              <p className="flex items-start gap-2">
                <Icon name="info" className="mt-0.5 h-4 w-4 shrink-0 text-at-blue" />
                <span>
                  Ces informations sont destinées exclusivement à la confection de votre carte d&apos;adhésion
                  ANRAT et au suivi de votre dossier. La photo d&apos;identité, si elle a été fournie, est
                  conservée par l&apos;association et n&apos;apparaît pas sur ce document imprimé.
                </span>
              </p>
            </div>

            <div className="mt-8 flex flex-col justify-between gap-6 text-[0.7rem] text-slate-500 sm:flex-row">
              <p>Signature de l&apos;adhérent : ......................................</p>
              <p>Cachet de l&apos;association : ......................................</p>
            </div>

            <p className="mt-6 border-t border-slate-100 pt-3 text-center text-[0.65rem] text-at-muted">
              ANRAT — {ASSOCIATION.longName} · {ASSOCIATION.email} · Document généré automatiquement
            </p>
          </div>
        </section>

        <div className="no-print mt-5 flex flex-wrap items-center justify-between gap-3 text-xs text-at-muted">
          <p>Conservez cette référence pour tout échange avec l&apos;association.</p>
          <Link href="/#adhesion" className="font-semibold text-at-blue hover:underline">
            Déposer une nouvelle demande
          </Link>
        </div>
      </main>

      <SiteFooter />
    </>
  );
}
