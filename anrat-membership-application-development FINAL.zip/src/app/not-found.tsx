import Link from "next/link";
import { AnratLogo } from "@/components/AnratLogo";
import { Icon } from "@/components/Icons";
import { ASSOCIATION } from "@/lib/constants";

export default function NotFound() {
  return (
    <main className="brand-gradient relative grid min-h-screen place-items-center overflow-hidden px-4 py-12 text-white">
      <div className="grid-pattern pointer-events-none absolute inset-0 opacity-60" aria-hidden="true" />
      <div className="relative w-full max-w-lg rounded-3xl border border-white/20 bg-white p-8 text-center shadow-2xl">
        <span className="mx-auto grid h-20 w-20 place-items-center rounded-2xl bg-white ring-1 ring-slate-200">
          <AnratLogo className="h-16 w-16" />
        </span>
        <p className="mt-5 text-[0.65rem] font-bold uppercase tracking-[0.18em] text-at-green">
          ANRAT · Espace adhérent
        </p>
        <h1 className="mt-2 text-2xl font-extrabold tracking-tight text-at-navy">Page introuvable</h1>
        <p className="mt-3 text-sm leading-relaxed text-slate-600">
          Nous n&apos;avons pas trouvé cette page ou la référence de demande demandée. Vérifiez la référence
          reçue lors de l&apos;envoi, ou déposez une nouvelle demande.
        </p>
        <div className="mt-6 flex flex-col justify-center gap-2.5 sm:flex-row">
          <Link
            href="/"
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-at-blue px-5 py-3 text-sm font-bold text-white transition hover:bg-at-navy"
          >
            <Icon name="arrowLeft" className="h-4 w-4" />
            Retour à l&apos;accueil
          </Link>
          <a
            href={`mailto:${ASSOCIATION.email}`}
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 px-5 py-3 text-sm font-bold text-slate-600 transition hover:border-at-blue/40 hover:text-at-blue"
          >
            <Icon name="mail" className="h-4 w-4" />
            Contacter l&apos;association
          </a>
        </div>
      </div>
    </main>
  );
}
