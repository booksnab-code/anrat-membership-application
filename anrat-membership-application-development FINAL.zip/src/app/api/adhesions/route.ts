import { db } from "@/db";
import { memberships } from "@/db/schema";
import { buildMailtoLink, forwardMembership, type ForwardPayload } from "@/lib/forwarding";
import { referenceFor } from "@/lib/references";
import { fieldErrors, membershipSchema } from "@/lib/validation";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const attempts = new Map<string, number[]>();
const WINDOW_MS = 10 * 60 * 1000;
const MAX_ATTEMPTS = 8;

function isRateLimited(key: string): boolean {
  const now = Date.now();
  const history = (attempts.get(key) ?? []).filter((time) => now - time < WINDOW_MS);
  history.push(now);
  attempts.set(key, history);
  if (attempts.size > 500) {
    for (const [entry, times] of attempts) {
      if (times.every((time) => now - time > WINDOW_MS)) attempts.delete(entry);
    }
  }
  return history.length > MAX_ATTEMPTS;
}

export async function POST(request: Request) {
  const ip =
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip") ||
    "local";

  if (isRateLimited(ip)) {
    return Response.json(
      { ok: false, error: "Trop de demandes envoyées. Merci de réessayer dans quelques minutes." },
      { status: 429 },
    );
  }

  let raw: unknown;
  try {
    raw = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Requête invalide." }, { status: 400 });
  }

  const parsed = membershipSchema.safeParse(raw);
  if (!parsed.success) {
    return Response.json(
      {
        ok: false,
        error: "Certaines informations sont incomplètes ou invalides. Merci de vérifier le formulaire.",
        fieldErrors: fieldErrors(parsed.error),
      },
      { status: 422 },
    );
  }

  const data = parsed.data;

  try {
    const [created] = await db
      .insert(memberships)
      .values({
        reference: `TMP-${crypto.randomUUID()}`,
        lastName: data.lastName,
        firstName: data.firstName,
        birthDate: data.birthDate,
        wilaya: data.wilaya,
        bloodType: data.bloodType,
        retirementDate: data.retirementDate,
        socialSecurityNumber: data.socialSecurityNumber,
        cnrNumber: data.cnrNumber,
        mobile: data.mobile,
        email: data.email,
        photoData: data.photoData || null,
        attachmentName: data.attachmentName || null,
        attachmentType: data.attachmentType || null,
        attachmentData: data.attachmentData || null,
        consent: data.consent,
      })
      .returning({ id: memberships.id, createdAt: memberships.createdAt });

    const reference = referenceFor(created.id, new Date(created.createdAt ?? Date.now()));
    await db.update(memberships).set({ reference }).where(eq(memberships.id, created.id));

    const submittedAt = new Date().toISOString();
    const payload: ForwardPayload = {
      reference,
      lastName: data.lastName,
      firstName: data.firstName,
      birthDate: data.birthDate,
      wilaya: data.wilaya,
      bloodType: data.bloodType,
      retirementDate: data.retirementDate,
      socialSecurityNumber: data.socialSecurityNumber,
      cnrNumber: data.cnrNumber,
      mobile: data.mobile,
      email: data.email,
      photoData: data.photoData ?? null,
      attachmentName: data.attachmentName ?? null,
      attachmentData: data.attachmentData ?? null,
      submittedAt,
    };

    const forward = await forwardMembership(payload);

    await db
      .update(memberships)
      .set({
        forwardStatus: forward.status,
        forwardChannel: forward.channel,
        forwardError: forward.error,
        updatedAt: new Date(),
      })
      .where(eq(memberships.id, created.id));

    return Response.json(
      {
        ok: true,
        reference,
        forward: {
          status: forward.status,
          channel: forward.channel,
          configured: forward.configured,
          delivered: forward.status === "transmise",
        },
        mailto: buildMailtoLink(payload),
        receiptUrl: `/adhesion/${reference}`,
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("[ANRAT] Échec de l'enregistrement de l'adhésion", error);
    return Response.json(
      {
        ok: false,
        error:
          "L'enregistrement de votre demande a échoué. Merci de réessayer ou de nous contacter par e-mail.",
      },
      { status: 500 },
    );
  }
}
