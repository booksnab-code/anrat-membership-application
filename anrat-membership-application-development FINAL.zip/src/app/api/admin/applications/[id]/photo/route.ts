import { db } from "@/db";
import { memberships } from "@/db/schema";
import { isAdminAuthenticated, unauthorized } from "@/lib/admin";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  if (!(await isAdminAuthenticated())) return unauthorized();

  const { id } = await context.params;
  const numericId = Number(id);
  if (!Number.isInteger(numericId) || numericId <= 0) {
    return Response.json({ ok: false, error: "Identifiant invalide." }, { status: 400 });
  }

  const [row] = await db
    .select({ photoData: memberships.photoData })
    .from(memberships)
    .where(eq(memberships.id, numericId))
    .limit(1);

  if (!row?.photoData) {
    return Response.json({ ok: false, error: "Aucune photo." }, { status: 404 });
  }

  const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,([\s\S]+)$/.exec(row.photoData);
  if (!match) {
    return Response.json({ ok: false, error: "Photo illisible." }, { status: 422 });
  }

  const buffer = Buffer.from(match[2], "base64");
  return new Response(new Uint8Array(buffer), {
    headers: {
      "Content-Type": match[1],
      "Cache-Control": "private, no-store",
    },
  });
}
