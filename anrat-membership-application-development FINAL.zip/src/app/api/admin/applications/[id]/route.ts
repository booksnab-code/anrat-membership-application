import { db } from "@/db";
import { memberships } from "@/db/schema";
import { isAdminAuthenticated, unauthorized } from "@/lib/admin";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const STATUSES = ["en_attente", "validee", "rejetee"];

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  if (!(await isAdminAuthenticated())) return unauthorized();

  const { id } = await context.params;
  const numericId = Number(id);
  if (!Number.isInteger(numericId) || numericId <= 0) {
    return Response.json({ ok: false, error: "Identifiant invalide." }, { status: 400 });
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Requête invalide." }, { status: 400 });
  }

  const payload = (body ?? {}) as { status?: unknown; adminNote?: unknown };
  const updates: { status?: string; adminNote?: string | null; updatedAt: Date } = { updatedAt: new Date() };

  if (typeof payload.status === "string") {
    if (!STATUSES.includes(payload.status)) {
      return Response.json({ ok: false, error: "Statut inconnu." }, { status: 400 });
    }
    updates.status = payload.status;
  }

  if (typeof payload.adminNote === "string" || payload.adminNote === null) {
    updates.adminNote = payload.adminNote ? String(payload.adminNote).slice(0, 1000) : null;
  }

  try {
    const [updated] = await db
      .update(memberships)
      .set(updates)
      .where(eq(memberships.id, numericId))
      .returning({
        id: memberships.id,
        status: memberships.status,
        adminNote: memberships.adminNote,
      });

    if (!updated) {
      return Response.json({ ok: false, error: "Demande introuvable." }, { status: 404 });
    }

    return Response.json({ ok: true, application: updated });
  } catch (error) {
    console.error("[ANRAT] Mise à jour de la demande impossible", error);
    return Response.json({ ok: false, error: "Mise à jour impossible." }, { status: 500 });
  }
}
