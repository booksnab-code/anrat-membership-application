import { db } from "@/db";
import { memberships } from "@/db/schema";
import { isAdminAuthenticated, unauthorized } from "@/lib/admin";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  if (!(await isAdminAuthenticated())) return unauthorized();

  const { id } = await context.params;
  const numericId = Number(id);
  if (!Number.isInteger(numericId) || numericId <= 0) {
    return Response.json({ ok: false, error: "Identifiant invalide." }, { status: 400 });
  }

  const [row] = await db
    .select({
      attachmentData: memberships.attachmentData,
      attachmentName: memberships.attachmentName,
      attachmentType: memberships.attachmentType,
    })
    .from(memberships)
    .where(eq(memberships.id, numericId))
    .limit(1);

  if (!row?.attachmentData) {
    return Response.json({ ok: false, error: "Aucune pièce jointe." }, { status: 404 });
  }

  const base64 = row.attachmentData.split(",")[1] ?? "";
  const buffer = Buffer.from(base64, "base64");
  const filename = (row.attachmentName || "piece-jointe").replace(/["\r\n]/g, "_");

  return new Response(new Uint8Array(buffer), {
    headers: {
      "Content-Type": row.attachmentType || "application/octet-stream",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}
