import { db } from "@/db";
import { memberships } from "@/db/schema";
import { isAdminAuthenticated, unauthorized } from "@/lib/admin";
import { integrationSummary } from "@/lib/forwarding";
import { and, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";

export const dynamic = "force-dynamic";

const STATUSES = new Set(["en_attente", "validee", "rejetee"]);

export async function GET(request: Request) {
  if (!(await isAdminAuthenticated())) return unauthorized();

  const url = new URL(request.url);
  const q = url.searchParams.get("q")?.trim() ?? "";
  const status = url.searchParams.get("status") ?? "all";

  const filters: SQL[] = [];
  if (STATUSES.has(status)) {
    filters.push(eq(memberships.status, status));
  }
  if (q) {
    const term = `%${q}%`;
    const search = or(
      ilike(memberships.reference, term),
      ilike(memberships.lastName, term),
      ilike(memberships.firstName, term),
      ilike(memberships.mobile, term),
      ilike(memberships.email, term),
      ilike(memberships.wilaya, term),
    );
    if (search) filters.push(search);
  }

  try {
    const rows = await db
      .select({
        id: memberships.id,
        reference: memberships.reference,
        lastName: memberships.lastName,
        firstName: memberships.firstName,
        birthDate: memberships.birthDate,
        wilaya: memberships.wilaya,
        bloodType: memberships.bloodType,
        retirementDate: memberships.retirementDate,
        socialSecurityNumber: memberships.socialSecurityNumber,
        cnrNumber: memberships.cnrNumber,
        mobile: memberships.mobile,
        email: memberships.email,
        photoData: memberships.photoData,
        attachmentName: memberships.attachmentName,
        attachmentType: memberships.attachmentType,
        status: memberships.status,
        adminNote: memberships.adminNote,
        forwardStatus: memberships.forwardStatus,
        forwardChannel: memberships.forwardChannel,
        forwardError: memberships.forwardError,
        createdAt: memberships.createdAt,
      })
      .from(memberships)
      .where(filters.length > 0 ? and(...filters) : undefined)
      .orderBy(desc(memberships.createdAt))
      .limit(300);

    const [stats] = await db
      .select({
        total: sql<number>`count(*)::int`,
        pending: sql<number>`count(*) filter (where ${memberships.status} = 'en_attente')::int`,
        validated: sql<number>`count(*) filter (where ${memberships.status} = 'validee')::int`,
        rejected: sql<number>`count(*) filter (where ${memberships.status} = 'rejetee')::int`,
        thisMonth: sql<number>`count(*) filter (where ${memberships.createdAt} >= date_trunc('month', now()))::int`,
        withPhoto: sql<number>`count(*) filter (where ${memberships.photoData} is not null)::int`,
      })
      .from(memberships);

    return Response.json({
      ok: true,
      applications: rows.map((row) => ({
        ...row,
        photoData: row.photoData ? "available" : null,
        createdAt: row.createdAt?.toISOString() ?? null,
      })),
      stats: stats ?? {
        total: 0,
        pending: 0,
        validated: 0,
        rejected: 0,
        thisMonth: 0,
        withPhoto: 0,
      },
      integration: integrationSummary(),
    });
  } catch (error) {
    console.error("[ANRAT] Lecture des adhésions impossible", error);
    return Response.json({ ok: false, error: "Lecture des demandes impossible." }, { status: 500 });
  }
}
