import { db } from "@/db";
import { memberships } from "@/db/schema";
import { isAdminAuthenticated, unauthorized } from "@/lib/admin";
import { STATUS_LABELS } from "@/lib/constants";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

function cell(value: unknown): string {
  const text = value === null || value === undefined ? "" : String(value);
  return `"${text.replace(/"/g, '""')}"`;
}

export async function GET() {
  if (!(await isAdminAuthenticated())) return unauthorized();

  const rows = await db
    .select({
      reference: memberships.reference,
      lastName: memberships.lastName,
      firstName: memberships.firstName,
      birthDate: memberships.birthDate,
      wilaya: memberships.wilaya,
      bloodType: memberships.bloodType,
      retirementDate: memberships.retirementDate,
      socialSecurityNumber: memberships.socialSecurityNumber,
      cnrNumber: memberships.cnrNumber,
      mobile: memberships.mobile,
      email: memberships.email,
      photoData: memberships.photoData,
      attachmentName: memberships.attachmentName,
      status: memberships.status,
      forwardStatus: memberships.forwardStatus,
      forwardChannel: memberships.forwardChannel,
      adminNote: memberships.adminNote,
      createdAt: memberships.createdAt,
    })
    .from(memberships)
    .orderBy(desc(memberships.createdAt));

  const header = [
    "Référence",
    "Nom",
    "Prénom",
    "Date de naissance",
    "Wilaya",
    "Rhésus",
    "Départ retraite",
    "N° SS",
    "N° CNR",
    "Mobile",
    "E-mail",
    "Photo",
    "Pièce jointe",
    "Statut",
    "Transmission",
    "Canal",
    "Note",
    "Déposée le",
  ];

  const lines = [header.map(cell).join(";")];
  for (const row of rows) {
    lines.push(
      [
        row.reference,
        row.lastName,
        row.firstName,
        row.birthDate,
        row.wilaya,
        row.bloodType,
        row.retirementDate,
        row.socialSecurityNumber,
        row.cnrNumber,
        row.mobile,
        row.email,
        row.photoData ? "Oui" : "Non",
        row.attachmentName ?? "",
        STATUS_LABELS[row.status] ?? row.status,
        row.forwardStatus,
        row.forwardChannel ?? "",
        row.adminNote ?? "",
        row.createdAt ? row.createdAt.toISOString().slice(0, 19).replace("T", " ") : "",
      ]
        .map(cell)
        .join(";"),
    );
  }

  const csv = `\uFEFF${lines.join("\r\n")}`;
  const date = new Date().toISOString().slice(0, 10);

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="anrat-adhesions-${date}.csv"`,
      "Cache-Control": "no-store",
    },
  });
}
