import { ADMIN_COOKIE, isDefaultPassword, isValidPassword, sessionToken } from "@/lib/admin";
import { cookies } from "next/headers";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Requête invalide." }, { status: 400 });
  }

  const password =
    body && typeof body === "object" && "password" in body ? String((body as { password: unknown }).password) : "";

  if (!password || !isValidPassword(password)) {
    return Response.json({ ok: false, error: "Mot de passe incorrect." }, { status: 401 });
  }

  const store = await cookies();
  store.set(ADMIN_COOKIE, sessionToken(), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 8,
  });

  return Response.json({ ok: true, defaultPassword: isDefaultPassword() });
}

export async function DELETE() {
  const store = await cookies();
  store.delete(ADMIN_COOKIE);
  return Response.json({ ok: true });
}
