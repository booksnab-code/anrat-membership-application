import Link from "next/link";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { memberships } from "@/db/schema";
import { AnratLogo } from "@/components/AnratLogo";
import { Icon } from "@/components/Icons";
import { MembershipForm } from "@/components/MembershipForm";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";
import { ASSOCIATION } from "@/lib/constants";

export const dynamic = "force-dynamic";

async function getStats() {
  try {
    const [row] = await db
      .select({
        total: sql<number>`count(*)::int`,
        validated: sql<number>`count(*) filter (where ${memberships.status} = 'validee')::int`,
      })
      .from(memberships);
    return row ?? { total: 0, validated: 0 };
  } catch {
    return { total: 0, validated: 0 };
  }
}

const REASSURANCE = [
  {
    icon: "clock" as const,
    title: "2 minutes",
    text: "Un formulaire court, en trois étapes guidées.",
  },
  {
    icon: "idCard" as const,
    title: "Carte d'adhésion",
    text: "Vos informations servent à éditer votre carte ANRAT.",
  },
  {
    icon: "shield" as const,
    title: "Données protégées",
    text: "Transmission sécurisée au dossier de l'association.",
  },
];

const STEPS = [
  {
    icon: "user" as const,
    title: "Remplissez le formulaire",
    text: "Vos informations personnelles, de retraite et de contact. Ajoutez une photo si vous le souhaitez.",
  },
  {
    icon: "send" as const,
    title: "Envoyez votre demande",
    text: "Un clic suffit : votre dossier arrive auprès de l'ANRAT et une référence vous est attribuée.",
  },
  {
    icon: "badgeCheck" as const,
    title: "Recevez votre carte",
    text: "L'association vérifie votre dossier, vous contacte et vous remet votre carte d'adhérent.",
  },
];

export default async function HomePage() {
  const stats = await getStats();

  return (
    <>
      <SiteHeader active="adhesion" />

      {/* HERO */}
      <section className="brand-gradient relative overflow-hidden text-white no-print">
        <div className="grid-pattern pointer-events-none absolute inset-0 opacity-60" aria-hidden="true" />
        <div
          className="pointer-events-none absolute -right-24 top-10 h-72 w-72 rounded-full border border-white/10"
          aria-hidden="true"
        />
        <div
          className="pointer-events-none absolute -left-16 bottom-0 h-64 w-64 rounded-full bg-at-green/20 blur-3xl"
          aria-hidden="true"
        />
        <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1.12fr_0.88fr] lg:py-16">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3.5 py-1.5 text-[0.65rem] font-bold uppercase tracking-[0.16em] text-white/90 backdrop-blur">
              <span className="h-1.5 w-1.5 rounded-full bg-at-green-500" />
              Association Nationale des Retraités · Algérie Télécom
            </span>
            <h1 className="text-balance mt-5 text-[2.1rem] font-extrabold leading-[1.08] tracking-tight sm:text-[2.9rem]">
              Votre adhésion à l&apos;ANRAT,
              <br className="hidden sm:block" />{" "}
              <span className="bg-gradient-to-r from-at-green-500 via-emerald-300 to-white bg-clip-text text-transparent">
                simple, digitale et solidaire.
              </span>
            </h1>
            <p className="mt-5 max-w-xl text-[0.95rem] leading-relaxed text-white/80">
              Bienvenue dans la grande famille des retraités d&apos;Algérie Télécom ! Rejoignez l&apos;ANRAT en
              quelques minutes : remplissez le formulaire, envoyez votre demande et recevez votre carte
              d&apos;adhésion.
            </p>

            <div className="mt-7 flex flex-wrap items-center gap-3">
              <Link
                href="#adhesion"
                className="inline-flex items-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-bold text-at-navy shadow-lg transition hover:bg-slate-100"
              >
                Remplir ma demande
                <Icon name="arrowRight" className="h-4 w-4" />
              </Link>
              <Link
                href="#suivi"
                className="inline-flex items-center gap-2 rounded-xl border border-white/30 bg-white/5 px-5 py-3 text-sm font-bold text-white backdrop-blur transition hover:bg-white/15"
              >
                <Icon name="search" className="h-4 w-4" />
                Suivre ma demande
              </Link>
            </div>

            <div className="mt-7 flex flex-wrap gap-x-5 gap-y-2 text-[0.72rem] text-white/70">
              {["Gratuit pour les retraités d'Algérie Télécom", "Carte d'adhésion officielle", "Assistance par e-mail"].map(
                (item) => (
                  <span key={item} className="inline-flex items-center gap-1.5">
                    <Icon name="checkCircle" className="h-3.5 w-3.5 text-at-green-500" />
                    {item}
                  </span>
                ),
              )}
            </div>
          </div>

          <div className="glass-card relative rounded-3xl p-5 shadow-2xl sm:p-6">
            <div className="flex items-center gap-3">
              <span className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-white">
                <AnratLogo className="h-14 w-14" />
              </span>
              <div>
                <p className="text-[1.05rem] font-extrabold leading-tight tracking-wide">ANRAT</p>
                <p className="text-[0.68rem] leading-snug text-white/70">{ASSOCIATION.longName}</p>
                <p className="mt-1 text-[0.6rem] font-semibold uppercase tracking-[0.12em] text-at-green-500">
                  Exercice 2026
                </p>
              </div>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-white/15 bg-white/10 p-3">
                <p className="text-2xl font-extrabold tracking-tight text-white">{stats.total}</p>
                <p className="text-[0.62rem] uppercase tracking-[0.1em] text-white/65">Demandes reçues</p>
              </div>
              <div className="rounded-xl border border-white/15 bg-white/10 p-3">
                <p className="text-2xl font-extrabold tracking-tight text-white">{stats.validated}</p>
                <p className="text-[0.62rem] uppercase tracking-[0.1em] text-white/65">Adhésions validées</p>
              </div>
            </div>

            <p className="mt-4 text-[0.7rem] font-bold uppercase tracking-[0.14em] text-white/60">
              À préparer
            </p>
            <ul className="mt-2 space-y-2 text-[0.75rem] text-white/85">
              {[
                "Votre numéro de sécurité sociale",
                "Votre numéro CNR",
                "Une photo d'identité (facultative)",
              ].map((item) => (
                <li key={item} className="flex items-start gap-2">
                  <Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-at-green-500" />
                  {item}
                </li>
              ))}
            </ul>

            <div className="mt-5 flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2 text-[0.68rem] text-white/80">
              <Icon name="lock" className="h-3.5 w-3.5 text-at-green-500" />
              Formulaire officiel de l&apos;ANRAT — {ASSOCIATION.email}
            </div>
          </div>
        </div>
      </section>

      {/* REASSURANCE */}
      <div className="no-print relative z-10 mx-auto -mt-6 max-w-6xl px-4 sm:px-6">
        <div className="grid gap-px overflow-hidden rounded-2xl border border-slate-200 bg-slate-200 shadow-soft sm:grid-cols-3">
          {REASSURANCE.map((item) => (
            <div key={item.title} className="flex items-start gap-3 bg-white px-4 py-4">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-at-blue/10 text-at-blue">
                <Icon name={item.icon} className="h-[18px] w-[18px]" />
              </span>
              <div>
                <p className="text-sm font-bold text-at-navy">{item.title}</p>
                <p className="mt-0.5 text-[0.72rem] leading-snug text-at-muted">{item.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <div className="no-print mb-7 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="flex items-center gap-2 text-[0.65rem] font-bold uppercase tracking-[0.18em] text-at-green">
              <span className="h-1.5 w-1.5 rounded-full bg-at-green" />
              Formulaire d&apos;adhésion
            </p>
            <h2 className="mt-2 text-2xl font-extrabold tracking-tight text-at-navy sm:text-3xl">
              Votre demande d&apos;adhésion ANRAT
            </h2>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-600">
              Toutes les informations demandées sont nécessaires à la confection de votre carte
              d&apos;adhésion. Les champs marqués d&apos;un astérisque sont obligatoires.
            </p>
          </div>
          <div className="flex shrink-0 flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-at-green/30 bg-at-green/5 px-3 py-1.5 text-[0.7rem] font-bold text-at-green">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-at-green" />
              Adhésion ouverte
            </span>
            <a
              href={`mailto:${ASSOCIATION.email}`}
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-[0.7rem] font-semibold text-slate-600 transition hover:border-at-blue/40 hover:text-at-blue"
            >
              <Icon name="mail" className="h-3.5 w-3.5" />
              Besoin d&apos;aide ?
            </a>
          </div>
        </div>

        <MembershipForm />

        {/* STEPS */}
        <section className="no-print mt-14">
          <div className="mb-6 text-center">
            <p className="text-[0.65rem] font-bold uppercase tracking-[0.18em] text-at-blue">
              Comment ça marche
            </p>
            <h2 className="mt-2 text-2xl font-extrabold tracking-tight text-at-navy">
              Votre adhésion en trois étapes
            </h2>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {STEPS.map((step, index) => (
              <div
                key={step.title}
                className="relative overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 shadow-soft"
              >
                <span className="absolute right-4 top-3 text-4xl font-extrabold text-slate-100">
                  {index + 1}
                </span>
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-at-navy text-white">
                  <Icon name={step.icon} className="h-5 w-5" />
                </span>
                <h3 className="mt-4 text-sm font-bold text-at-navy">{step.title}</h3>
                <p className="mt-1.5 text-[0.8rem] leading-relaxed text-slate-600">{step.text}</p>
              </div>
            ))}
          </div>
        </section>

        {/* HELP BAND */}
        <section className="no-print mt-10 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-soft">
          <div className="grid gap-6 p-6 sm:grid-cols-[1.4fr_1fr] sm:items-center sm:p-8">
            <div>
              <h2 className="text-lg font-extrabold text-at-navy sm:text-xl">
                Une question sur votre adhésion ou votre carte ?
              </h2>
              <p className="mt-2 max-w-xl text-sm leading-relaxed text-slate-600">
                L&apos;équipe de l&apos;ANRAT vous accompagne dans votre démarche. Écrivez-nous en précisant
                votre nom, votre wilaya et, si vous en avez une, votre référence de demande.
              </p>
            </div>
            <div className="flex flex-col gap-2.5 sm:items-end">
              <a
                href={`mailto:${ASSOCIATION.email}`}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-at-navy px-5 py-3 text-sm font-bold text-white transition hover:bg-at-blue"
              >
                <Icon name="mail" className="h-4 w-4" />
                {ASSOCIATION.email}
              </a>
              <Link
                href="#adhesion"
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 px-5 py-3 text-sm font-bold text-slate-600 transition hover:border-at-blue/40 hover:text-at-blue"
              >
                Revenir au formulaire
                <Icon name="arrowRight" className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
    </>
  );
}
