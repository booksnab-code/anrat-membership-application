import type { Metadata } from "next";
import type { ReactNode } from "react";

export const metadata: Metadata = {
  title: "Espace association — Gestion des adhésions ANRAT",
  description:
    "Espace réservé à l'Association Nationale des Retraités d'Algérie Télécom : consultation, validation et export des demandes d'adhésion.",
  robots: { index: false, follow: false },
};

export default function AdminLayout({ children }: { children: ReactNode }) {
  return children;
}
