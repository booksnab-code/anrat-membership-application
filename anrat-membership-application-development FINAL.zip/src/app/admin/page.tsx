"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { AnratLogo } from "@/components/AnratLogo";
import { Icon } from "@/components/Icons";
import {
  ASSOCIATION,
  FORWARD_LABELS,
  STATUS_LABELS,
  formatDateFr,
  formatDateTimeFr,
  wilayaLabel,
} from "@/lib/constants";

type AdminApplication = {
  id: number;
  reference: string;
  lastName: string;
  firstName: string;
  birthDate: string;
  wilaya: string;
  bloodType: string;
  retirementDate: string;
  socialSecurityNumber: string;
  cnrNumber: string;
  mobile: string;
  email: string;
  photoData: string | null;
  attachmentName: string | null;
  attachmentType: string | null;
  status: string;
  adminNote: string | null;
  forwardStatus: string;
  forwardChannel: string | null;
  forwardError: string | null;
  createdAt: string | null;
};

type Stats = {
  total: number;
  pending: number;
  validated: number;
  rejected: number;
  thisMonth: number;
  withPhoto: number;
};

type Integration = {
  googleForm: boolean;
  googleDrive: boolean;
  email: boolean;
  configured: boolean;
  associationEmail: string;
  formUrl: string | null;
  driveConnected: boolean;
};

const STATUS_BADGES: Record<string, string> = {
  en_attente: "bg-amber-50 text-amber-700 ring-amber-200",
  validee: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  rejetee: "bg-rose-50 text-rose-700 ring-rose-200",
};

const FORWARD_BADGES: Record<string, string> = {
  transmise: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  echec: "bg-rose-50 text-rose-700 ring-rose-200",
  non_configure: "bg-slate-50 text-slate-600 ring-slate-200",
};

export default function AdminPage() {
  const [session, setSession] = useState<"checking" | "guest" | "authed">("checking");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loggingIn, setLoggingIn] = useState(false);
  const [defaultPassword, setDefaultPassword] = useState(false);

  const [applications, setApplications] = useState<AdminApplication[]>([]);
  const [stats, setStats] = useState<Stats>({
    total: 0,
    pending: 0,
    validated: 0,
    rejected: 0,
    thisMonth: 0,
    withPhoto: 0,
  });
  const [integration, setIntegration] = useState<Integration | null>(null);
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [loading, setLoading] = useState(false);
  const [listError, setListError] = useState<string | null>(null);
  const [selected, setSelected] = useState<AdminApplication | null>(null);
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    const timeout = setTimeout(() => setDebouncedQuery(query.trim()), 350);
    return () => clearTimeout(timeout);
  }, [query]);

  const load = useCallback(async () => {
    setLoading(true);
    setListError(null);
    try {
      const params = new URLSearchParams();
      if (debouncedQuery) params.set("q", debouncedQuery);
      if (statusFilter !== "all") params.set("status", statusFilter);
      const response = await fetch(`/api/admin/applications?${params.toString()}`, {
        cache: "no-store",
      });
      if (response.status === 401) {
        setSession("guest");
        return;
      }
      const data = (await response.json()) as {
        ok: boolean;
        applications?: AdminApplication[];
        stats?: Stats;
        integration?: Integration;
        error?: string;
      };
      if (!response.ok || !data.ok) {
        setListError(data.error ?? "Chargement impossible.");
        return;
      }
      setSession("authed");
      setApplications(data.applications ?? []);
      if (data.stats) setStats(data.stats);
      if (data.integration) setIntegration(data.integration);
    } catch {
      setListError("Connexion au serveur impossible.");
    } finally {
      setLoading(false);
    }
  }, [debouncedQuery, statusFilter]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!toast) return;
    const timeout = setTimeout(() => setToast(null), 3500);
    return () => clearTimeout(timeout);
  }, [toast]);

  async function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoggingIn(true);
    setLoginError(null);
    try {
      const response = await fetch("/api/admin/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = (await response.json()) as { ok: boolean; error?: string; defaultPassword?: boolean };
      if (!response.ok || !data.ok) {
        setLoginError(data.error ?? "Connexion impossible.");
        return;
      }
      setPassword("");
      setDefaultPassword(Boolean(data.defaultPassword));
      await load();
    } catch {
      setLoginError("Connexion au serveur impossible.");
    } finally {
      setLoggingIn(false);
    }
  }

  async function handleLogout() {
    await fetch("/api/admin/session", { method: "DELETE" });
    setSession("guest");
    setApplications([]);
    setSelected(null);
  }

  async function updateApplication(id: number, payload: { status?: string; adminNote?: string }) {
    setSaving(true);
    try {
      const response = await fetch(`/api/admin/applications/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as { ok: boolean; error?: string };
      if (!response.ok || !data.ok) {
        setToast(data.error ?? "Mise à jour impossible.");
        return;
      }
      setToast("Demande mise à jour.");
      setSelected((current) => (current ? { ...current, ...payload } : current));
      await load();
    } catch {
      setToast("Mise à jour impossible.");
    } finally {
      setSaving(false);
    }
  }

  const pendingLabel = useMemo(
    () => (stats.pending > 1 ? `${stats.pending} demandes à traiter` : `${stats.pending} demande à traiter`),
    [stats.pending],
  );

  if (session === "checking") {
    return (
      <div className="brand-gradient grid min-h-screen place-items-center text-white">
        <div className="flex items-center gap-3 text-sm font-semibold">
          <span className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
          Vérification de l&apos;accès…
        </div>
      </div>
    );
  }

  if (session === "guest") {
    return (
      <div className="brand-gradient relative grid min-h-screen place-items-center overflow-hidden px-4 py-12">
        <div className="grid-pattern pointer-events-none absolute inset-0 opacity-60" aria-hidden="true" />
        <div
          className="pointer-events-none absolute -left-20 bottom-0 h-72 w-72 rounded-full bg-at-green/25 blur-3xl"
          aria-hidden="true"
        />
        <div className="relative w-full max-w-md">
          <div className="mb-5 flex items-center justify-center gap-3 text-white">
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-white">
              <AnratLogo className="h-12 w-12" />
            </span>
            <div>
              <p className="text-lg font-extrabold tracking-wide">ANRAT</p>
              <p className="text-[0.68rem] uppercase tracking-[0.14em] text-white/70">Espace association</p>
            </div>
          </div>
          <div className="rounded-3xl border border-white/20 bg-white p-6 shadow-2xl sm:p-8">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-at-navy/5 px-3 py-1 text-[0.62rem] font-bold uppercase tracking-[0.14em] text-at-navy">
              <Icon name="lock" className="h-3.5 w-3.5" />
              Accès réservé
            </span>
            <h1 className="mt-3 text-2xl font-extrabold tracking-tight text-at-navy">
              Gestion des adhésions
            </h1>
            <p className="mt-2 text-sm leading-relaxed text-slate-600">
              Cet espace permet à l&apos;association de consulter les demandes reçues, de les valider et
              d&apos;exporter les données pour la confection des cartes.
            </p>
            <form onSubmit={handleLogin} className="mt-5 space-y-3">
              <label htmlFor="admin-password" className="block text-xs font-bold uppercase tracking-wider text-at-navy">
                Mot de passe administrateur
              </label>
              <input
                id="admin-password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="••••••••"
                className="field-input"
              />
              {loginError ? (
                <p className="flex items-center gap-1.5 text-xs font-semibold text-at-red">
                  <Icon name="alert" className="h-3.5 w-3.5" />
                  {loginError}
                </p>
              ) : null}
              <button
                type="submit"
                disabled={loggingIn}
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-at-blue px-5 py-3 text-sm font-bold text-white transition hover:bg-at-navy disabled:opacity-70"
              >
                {loggingIn ? (
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
                ) : (
                  <Icon name="arrowRight" className="h-4 w-4" />
                )}
                Accéder à l&apos;espace
              </button>
            </form>
            <p className="mt-4 rounded-xl bg-slate-50 p-3 text-[0.7rem] leading-relaxed text-slate-500">
              Mot de passe par défaut de cette installation : <strong>ANRAT2022</strong>. Définissez la
              variable d&apos;environnement <code className="rounded bg-slate-200 px-1">ADMIN_PASSWORD</code>{" "}
              pour le personnaliser.
            </p>
            <Link
              href="/"
              className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-at-blue hover:underline"
            >
              <Icon name="arrowLeft" className="h-3.5 w-3.5" />
              Retour au formulaire d&apos;adhésion
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-at-sand">
      <header className="brand-gradient relative overflow-hidden text-white">
        <div className="grid-pattern pointer-events-none absolute inset-0 opacity-50" aria-hidden="true" />
        <div className="relative mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 py-5 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-xl bg-white">
              <AnratLogo className="h-10 w-10" />
            </span>
            <div>
              <p className="text-lg font-extrabold tracking-wide">Espace association</p>
              <p className="text-[0.68rem] uppercase tracking-[0.14em] text-white/70">
                ANRAT · Gestion des adhésions
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <a
              href="/api/admin/export"
              className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-xs font-bold text-at-navy transition hover:bg-slate-100"
            >
              <Icon name="download" className="h-4 w-4" />
              Exporter en CSV
            </a>
            <button
              type="button"
              onClick={() => void load()}
              className="inline-flex items-center gap-2 rounded-xl border border-white/25 bg-white/10 px-4 py-2.5 text-xs font-bold text-white transition hover:bg-white/20"
            >
              <Icon name="search" className="h-4 w-4" />
              Actualiser
            </button>
            <button
              type="button"
              onClick={() => void handleLogout()}
              className="inline-flex items-center gap-2 rounded-xl border border-white/25 bg-white/10 px-4 py-2.5 text-xs font-bold text-white transition hover:bg-white/20"
            >
              <Icon name="logout" className="h-4 w-4" />
              Déconnexion
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-7 sm:px-6">
        {defaultPassword ? (
          <div className="mb-4 flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 p-3.5 text-xs text-amber-800">
            <Icon name="alert" className="mt-0.5 h-4 w-4 shrink-0" />
            <span>
              Vous utilisez le mot de passe par défaut. Configurez la variable d&apos;environnement{" "}
              <code className="rounded bg-amber-100 px-1">ADMIN_PASSWORD</code> pour sécuriser cet espace.
            </span>
          </div>
        ) : null}

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { label: "Demandes reçues", value: stats.total, icon: "users" as const, tone: "text-at-blue" },
            { label: "À traiter", value: stats.pending, icon: "clock" as const, tone: "text-amber-600" },
            { label: "Adhésions validées", value: stats.validated, icon: "badgeCheck" as const, tone: "text-at-green" },
            { label: "Ce mois-ci", value: stats.thisMonth, icon: "calendar" as const, tone: "text-at-navy" },
          ].map((card) => (
            <div key={card.label} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-soft">
              <div className="flex items-center justify-between">
                <p className="text-[0.65rem] font-bold uppercase tracking-[0.12em] text-at-muted">
                  {card.label}
                </p>
                <Icon name={card.icon} className={`h-4 w-4 ${card.tone}`} />
              </div>
              <p className="mt-2 text-3xl font-extrabold tracking-tight text-at-navy">{card.value}</p>
            </div>
          ))}
        </div>

        <div className="mt-4 grid gap-4 lg:grid-cols-[1.5fr_1fr]">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-soft">
            <div className="flex items-center justify-between gap-2">
              <h2 className="flex items-center gap-2 text-sm font-bold text-at-navy">
                <Icon name="send" className="h-4 w-4 text-at-blue" />
                Transmission vers le Google Forms / Drive de l&apos;association
              </h2>
              <span
                className={`rounded-full px-2.5 py-1 text-[0.62rem] font-bold ring-1 ${
                  integration?.configured
                    ? "bg-emerald-50 text-emerald-700 ring-emerald-200"
                    : "bg-amber-50 text-amber-700 ring-amber-200"
                }`}
              >
                {integration?.configured ? "Connecté" : "À configurer"}
              </span>
            </div>
            <div className="mt-3 grid gap-2 sm:grid-cols-3">
              {[
                { label: "Google Forms", active: integration?.googleForm },
                { label: "Drive / Sheets", active: integration?.googleDrive },
                { label: "E-mail", active: integration?.email },
              ].map((channel) => (
                <div
                  key={channel.label}
                  className="flex items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-2 text-[0.7rem] font-semibold text-slate-600"
                >
                  <span
                    className={`h-2 w-2 rounded-full ${channel.active ? "bg-at-green" : "bg-slate-300"}`}
                  />
                  {channel.label}
                </div>
              ))}
            </div>
            <p className="mt-3 text-[0.72rem] leading-relaxed text-slate-600">
              Chaque demande est enregistrée dans la base de l&apos;application puis transmise
              automatiquement. Renseignez <code className="rounded bg-slate-100 px-1">GOOGLE_FORM_RESPONSE_URL</code>{" "}
              + <code className="rounded bg-slate-100 px-1">GOOGLE_FORM_FIELD_MAP</code>,{" "}
              <code className="rounded bg-slate-100 px-1">GOOGLE_SHEETS_WEBHOOK_URL</code> (Apps Script) ou{" "}
              <code className="rounded bg-slate-100 px-1">RESEND_API_KEY</code> pour activer la transmission
              vers <strong>{integration?.associationEmail ?? ASSOCIATION.email}</strong>.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-soft">
            <h2 className="flex items-center gap-2 text-sm font-bold text-at-navy">
              <Icon name="info" className="h-4 w-4 text-at-blue" />
              À retenir
            </h2>
            <ul className="mt-2 space-y-1.5 text-[0.74rem] leading-relaxed text-slate-600">
              <li className="flex gap-2">
                <Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-at-green" />
                {pendingLabel} dans la file d&apos;attente.
              </li>
              <li className="flex gap-2">
                <Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-at-green" />
                {stats.withPhoto} demande(s) avec photo d&apos;identité pour la carte.
              </li>
              <li className="flex gap-2">
                <Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-at-green" />
                Les photos et pièces jointes sont accessibles dans le détail d&apos;une demande.
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-5 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-soft">
          <div className="flex flex-col gap-3 border-b border-slate-100 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="relative w-full sm:max-w-xs">
              <Icon
                name="search"
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
              />
              <input
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Nom, référence, mobile, wilaya…"
                className="field-input pl-9 text-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <select
                value={statusFilter}
                onChange={(event) => setStatusFilter(event.target.value)}
                className="field-input w-auto text-xs font-semibold"
                aria-label="Filtrer par statut"
              >
                <option value="all">Tous les statuts</option>
                <option value="en_attente">En attente</option>
                <option value="validee">Validées</option>
                <option value="rejetee">Rejetées</option>
              </select>
              <span className="text-xs text-at-muted">{applications.length} résultat(s)</span>
            </div>
          </div>

          {listError ? (
            <div className="m-4 rounded-xl border border-at-red/20 bg-at-red/5 p-3 text-xs font-semibold text-at-red">
              {listError}
            </div>
          ) : null}

          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] border-collapse text-left text-sm">
              <thead>
                <tr className="bg-slate-50 text-[0.62rem] uppercase tracking-[0.1em] text-at-muted">
                  <th className="px-4 py-3 font-bold">Adhérent</th>
                  <th className="px-4 py-3 font-bold">Référence</th>
                  <th className="px-4 py-3 font-bold">Wilaya</th>
                  <th className="px-4 py-3 font-bold">Contact</th>
                  <th className="px-4 py-3 font-bold">Déposée le</th>
                  <th className="px-4 py-3 font-bold">Statut</th>
                  <th className="px-4 py-3 font-bold">Transmission</th>
                  <th className="px-4 py-3 font-bold text-right">Détail</th>
                </tr>
              </thead>
              <tbody>
                {applications.map((application) => (
                  <tr key={application.id} className="border-t border-slate-100 hover:bg-slate-50/70">
                    <td className="px-4 py-3">
                      <p className="font-bold text-at-navy">
                        {application.lastName.toUpperCase()} {application.firstName}
                      </p>
                      <p className="text-[0.68rem] text-at-muted">
                        {application.bloodType} · né(e) le {formatDateFr(application.birthDate)}
                      </p>
                    </td>
                    <td className="px-4 py-3 font-mono text-[0.7rem] text-slate-600">
                      {application.reference}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-600">{wilayaLabel(application.wilaya)}</td>
                    <td className="px-4 py-3 text-xs text-slate-600">
                      <p>{application.mobile}</p>
                      <p className="text-[0.68rem] text-at-muted">{application.email}</p>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-600">
                      {formatDateTimeFr(application.createdAt)}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex rounded-full px-2.5 py-1 text-[0.64rem] font-bold ring-1 ${
                          STATUS_BADGES[application.status] ?? STATUS_BADGES.en_attente
                        }`}
                      >
                        {STATUS_LABELS[application.status] ?? application.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex rounded-full px-2.5 py-1 text-[0.62rem] font-semibold ring-1 ${
                          FORWARD_BADGES[application.forwardStatus] ?? FORWARD_BADGES.non_configure
                        }`}
                      >
                        {FORWARD_LABELS[application.forwardStatus] ?? application.forwardStatus}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        type="button"
                        onClick={() => {
                          setSelected(application);
                          setNote(application.adminNote ?? "");
                        }}
                        className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-2.5 py-1.5 text-[0.68rem] font-bold text-at-blue transition hover:border-at-blue/40 hover:bg-at-blue/5"
                      >
                        Ouvrir
                        <Icon name="arrowRight" className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
                {applications.length === 0 && !loading ? (
                  <tr>
                    <td colSpan={8} className="px-4 py-12 text-center text-sm text-at-muted">
                      Aucune demande ne correspond à votre recherche.
                    </td>
                  </tr>
                ) : null}
                {loading ? (
                  <tr>
                    <td colSpan={8} className="px-4 py-10 text-center text-sm text-at-muted">
                      <span className="inline-flex items-center gap-2">
                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-slate-300 border-t-at-blue" />
                        Chargement des demandes…
                      </span>
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </div>

        <p className="mt-4 text-center text-[0.7rem] text-at-muted">
          ANRAT · Espace de gestion interne — les données sont strictement confidentielles.
        </p>
      </main>

      {selected ? (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-at-navy/50 p-4 backdrop-blur-sm sm:items-center">
          <div className="my-6 w-full max-w-2xl overflow-hidden rounded-2xl bg-white shadow-2xl">
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 bg-gradient-to-r from-slate-50 to-white p-5">
              <div>
                <p className="font-mono text-[0.68rem] font-semibold text-at-blue">{selected.reference}</p>
                <h2 className="mt-1 text-lg font-extrabold text-at-navy">
                  {selected.lastName.toUpperCase()} {selected.firstName}
                </h2>
                <p className="text-xs text-at-muted">
                  Déposée le {formatDateTimeFr(selected.createdAt)} · {wilayaLabel(selected.wilaya)}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelected(null)}
                aria-label="Fermer"
                className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:bg-slate-100"
              >
                <Icon name="close" className="h-4 w-4" />
              </button>
            </div>

            <div className="max-h-[60vh] overflow-y-auto p-5">
              <div className="flex gap-4">
                <div className="h-28 w-[86px] shrink-0 overflow-hidden rounded-lg border border-slate-200 bg-slate-50">
                  {selected.photoData ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={`/api/admin/applications/${selected.id}/photo`}
                      alt={`Photo de ${selected.firstName} ${selected.lastName}`}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="grid h-full w-full place-items-center text-[0.6rem] text-slate-400">
                      Sans photo
                    </div>
                  )}
                </div>
                <dl className="grid flex-1 gap-x-4 gap-y-1.5 sm:grid-cols-2">
                  {[
                    ["Naissance", formatDateFr(selected.birthDate)],
                    ["Rhésus", selected.bloodType],
                    ["Départ retraite", formatDateFr(selected.retirementDate)],
                    ["N° SS", selected.socialSecurityNumber],
                    ["N° CNR", selected.cnrNumber],
                    ["Mobile", selected.mobile],
                    ["E-mail", selected.email],
                    ["Pièce jointe", selected.attachmentName || "Aucune"],
                  ].map(([label, value]) => (
                    <div key={label} className="border-b border-dashed border-slate-100 pb-1">
                      <dt className="text-[0.6rem] uppercase tracking-wider text-at-muted">{label}</dt>
                      <dd className="break-words text-xs font-semibold text-at-navy">{value}</dd>
                    </div>
                  ))}
                </dl>
              </div>

              {selected.attachmentName ? (
                <a
                  href={`/api/admin/applications/${selected.id}/attachment`}
                  className="mt-3 inline-flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-xs font-bold text-at-blue transition hover:bg-at-blue/5"
                >
                  <Icon name="download" className="h-4 w-4" />
                  Télécharger la pièce jointe
                </a>
              ) : null}

              {selected.forwardStatus !== "transmise" ? (
                <p className="mt-3 rounded-lg bg-slate-50 p-3 text-[0.7rem] leading-relaxed text-slate-600">
                  Transmission : {FORWARD_LABELS[selected.forwardStatus] ?? selected.forwardStatus}
                  {selected.forwardError ? ` — ${selected.forwardError}` : ""}. La demande reste disponible
                  dans cet espace.
                </p>
              ) : null}

              <div className="mt-4">
                <label
                  htmlFor="admin-note"
                  className="mb-1.5 block text-[0.65rem] font-bold uppercase tracking-wider text-at-navy"
                >
                  Note interne
                </label>
                <textarea
                  id="admin-note"
                  value={note}
                  onChange={(event) => setNote(event.target.value)}
                  rows={3}
                  maxLength={1000}
                  placeholder="Carte éditée, pièce manquante, appel effectué…"
                  className="field-input resize-none text-sm"
                />
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void updateApplication(selected.id, { adminNote: note })}
                  className="mt-2 inline-flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-xs font-bold text-slate-600 transition hover:border-at-blue/40 hover:text-at-blue disabled:opacity-60"
                >
                  <Icon name="check" className="h-3.5 w-3.5" />
                  Enregistrer la note
                </button>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 bg-slate-50/70 p-4">
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void updateApplication(selected.id, { status: "validee" })}
                  className="inline-flex items-center gap-2 rounded-xl bg-at-green px-4 py-2.5 text-xs font-bold text-white transition hover:bg-at-green/90 disabled:opacity-60"
                >
                  <Icon name="checkCircle" className="h-4 w-4" />
                  Valider l&apos;adhésion
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void updateApplication(selected.id, { status: "rejetee" })}
                  className="inline-flex items-center gap-2 rounded-xl border border-at-red/30 bg-white px-4 py-2.5 text-xs font-bold text-at-red transition hover:bg-at-red/5 disabled:opacity-60"
                >
                  <Icon name="alert" className="h-4 w-4" />
                  Rejeter
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void updateApplication(selected.id, { status: "en_attente" })}
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs font-bold text-slate-600 transition hover:border-at-blue/40 disabled:opacity-60"
                >
                  <Icon name="clock" className="h-4 w-4" />
                  Remettre en attente
                </button>
              </div>
              <button
                type="button"
                onClick={() => setSelected(null)}
                className="rounded-xl px-3 py-2 text-xs font-bold text-slate-500 hover:text-at-navy"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {toast ? (
        <div className="fixed bottom-5 left-1/2 z-[60] -translate-x-1/2 rounded-xl bg-at-navy px-4 py-2.5 text-xs font-semibold text-white shadow-xl">
          {toast}
        </div>
      ) : null}
    </div>
  );
}
