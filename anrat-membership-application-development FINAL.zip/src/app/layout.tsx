import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Adhésion ANRAT — Association Nationale des Retraités d'Algérie Télécom",
  description:
    "Formulaire d'adhésion en ligne de l'ANRAT, l'Association Nationale des Retraités d'Algérie Télécom. Renseignez vos informations personnelles, de retraite et de contact pour obtenir votre carte d'adhésion.",
  applicationName: "ANRAT — Adhésion",
  keywords: [
    "ANRAT",
    "Algérie Télécom",
    "adhésion",
    "retraités",
    "association",
    "carte d'adhésion",
  ],
  openGraph: {
    title: "Adhésion ANRAT — Retraités d'Algérie Télécom",
    description:
      "Rejoignez l'Association Nationale des Retraités d'Algérie Télécom : formulaire d'adhésion en ligne, carte d'adhérent et suivi de demande.",
    type: "website",
    locale: "fr_DZ",
  },
  icons: {
    icon: [{ url: "/favicon.svg", type: "image/svg+xml" }],
  },
};

export const viewport: Viewport = {
  themeColor: "#062a4a",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <body className="min-h-screen bg-at-sand text-ink antialiased">{children}</body>
    </html>
  );
}
