import {
  boolean,
  date,
  index,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/**
 * Demandes d'adhésion à l'Association Nationale des Retraités d'Algérie Télécom.
 * Les informations servent à la confection de la carte d'adhésion ANRAT.
 */
export const memberships = pgTable(
  "memberships",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull(),

    // I - Informations personnelles
    lastName: text("last_name").notNull(),
    firstName: text("first_name").notNull(),
    birthDate: date("birth_date").notNull(),
    wilaya: text("wilaya").notNull(),
    bloodType: text("blood_type").notNull(),

    // II - Retraite & santé
    retirementDate: date("retirement_date").notNull(),
    socialSecurityNumber: text("social_security_number").notNull(),
    cnrNumber: text("cnr_number").notNull(),

    // III - Contact personnel & pièces jointes
    mobile: text("mobile").notNull(),
    email: text("email").notNull(),
    photoData: text("photo_data"),
    attachmentName: text("attachment_name"),
    attachmentType: text("attachment_type"),
    attachmentData: text("attachment_data"),

    consent: boolean("consent").notNull().default(true),
    status: text("status").notNull().default("en_attente"),
    adminNote: text("admin_note"),

    forwardStatus: text("forward_status").notNull().default("non_configure"),
    forwardChannel: text("forward_channel"),
    forwardError: text("forward_error"),

    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("memberships_reference_uq").on(table.reference),
    index("memberships_created_at_idx").on(table.createdAt),
    index("memberships_status_idx").on(table.status),
  ],
);

export type Membership = typeof memberships.$inferSelect;
export type NewMembership = typeof memberships.$inferInsert;
