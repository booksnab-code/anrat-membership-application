import { AnratLogo } from "./AnratLogo";
import { Icon } from "./Icons";
import { wilayaLabel } from "@/lib/constants";

type CardProps = {
  firstName: string;
  lastName: string;
  wilaya: string;
  bloodType: string;
  photoData?: string;
  reference?: string;
};

export function MembershipCardPreview({
  firstName,
  lastName,
  wilaya,
  bloodType,
  photoData,
  reference,
}: CardProps) {
  const fullName = `${lastName} ${firstName}`.trim();
  const initials = `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-card">
      <div className="flex items-center justify-between gap-2 border-b border-slate-100 px-4 py-2.5">
        <p className="text-[0.65rem] font-bold uppercase tracking-[0.16em] text-at-muted">
          Aperçu de votre carte
        </p>
        <span className="flex items-center gap-1 text-[0.6rem] font-semibold uppercase tracking-wider text-at-green">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-at-green" />
          En direct
        </span>
      </div>

      <div className="p-3">
        <div className="brand-gradient relative overflow-hidden rounded-xl p-4 text-white">
          <div className="grid-pattern pointer-events-none absolute inset-0 opacity-70" aria-hidden="true" />
          <div
            className="pointer-events-none absolute -right-10 -top-12 h-32 w-32 rounded-full border border-white/15"
            aria-hidden="true"
          />
          <div
            className="pointer-events-none absolute -bottom-16 -left-10 h-36 w-36 rounded-full bg-at-green/30 blur-2xl"
            aria-hidden="true"
          />

          <div className="relative flex items-start justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center overflow-hidden rounded-full bg-white">
                <AnratLogo className="h-8 w-8" />
              </span>
              <div>
                <p className="text-[0.7rem] font-extrabold tracking-[0.18em]">ANRAT</p>
                <p className="text-[0.5rem] uppercase tracking-[0.14em] text-white/70">Carte d&apos;adhésion</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-[0.5rem] uppercase tracking-[0.14em] text-white/60">Algérie Télécom</p>
              <p className="text-[0.62rem] font-bold tracking-wider text-at-green-500">2026</p>
            </div>
          </div>

          <div className="relative mt-4 flex items-end gap-3">
            <div className="h-[68px] w-[54px] shrink-0 overflow-hidden rounded-lg border border-white/30 bg-white/12">
              {photoData ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={photoData} alt="Photo d'identité" className="h-full w-full object-cover" />
              ) : (
                <div className="grid h-full w-full place-items-center text-base font-bold text-white/70">
                  {initials || <Icon name="camera" className="h-5 w-5 text-white/60" />}
                </div>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[0.95rem] font-bold uppercase leading-tight tracking-wide">
                {fullName || "NOM PRÉNOM"}
              </p>
              <p className="mt-1 truncate text-[0.62rem] text-white/75">
                {wilaya ? wilayaLabel(wilaya) : "Wilaya de résidence"}
              </p>
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                <span className="rounded bg-white/15 px-1.5 py-0.5 text-[0.55rem] font-semibold uppercase tracking-wider">
                  Groupe {bloodType || "—"}
                </span>
                <span className="rounded bg-at-green/90 px-1.5 py-0.5 text-[0.55rem] font-bold uppercase tracking-wider">
                  Membre
                </span>
              </div>
            </div>
          </div>

          <div className="relative mt-3 flex items-end justify-between gap-2 border-t border-white/15 pt-2.5">
            <div>
              <p className="text-[0.45rem] uppercase tracking-[0.14em] text-white/55">N° d&apos;adhérent</p>
              <p className="font-mono text-[0.62rem] font-semibold tracking-wide">
                {reference ?? "ANRAT-••••-•••••"}
              </p>
            </div>
            <div className="flex h-6 items-end gap-[2px]" aria-hidden="true">
              {[3, 7, 2, 5, 8, 3, 6, 2, 7, 4, 8, 3, 5, 2, 6, 4].map((height, index) => (
                <span
                  key={`${height}-${index}`}
                  className="w-[2px] rounded-sm bg-white/70"
                  style={{ height: `${height + 2}px` }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      <p className="px-4 pb-4 text-[0.7rem] leading-relaxed text-at-muted">
        Cet aperçu se met à jour en temps réel. La carte officielle est éditée par l&apos;association après
        validation de votre demande.
      </p>
    </div>
  );
}
