type LogoProps = {
  className?: string;
  title?: string;
};

/**
 * Emblème ANRAT — croissant et étoile algériens (vert / rouge),
 * ondes télécom et typographie bleue « ANRAT ».
 */
export function AnratLogo({ className = "h-14 w-14", title = "Logo ANRAT" }: LogoProps) {
  return (
    <svg
      viewBox="0 0 132 132"
      role="img"
      aria-label={title}
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <clipPath id="anrat-clip">
          <circle cx="66" cy="66" r="61" />
        </clipPath>
        <mask id="anrat-crescent">
          <rect width="132" height="132" fill="black" />
          <circle cx="47" cy="46" r="18" fill="white" />
          <circle cx="56" cy="46" r="15.5" fill="black" />
        </mask>
        <linearGradient id="anrat-green" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#17a55f" />
          <stop offset="55%" stopColor="#0c7a4d" />
          <stop offset="100%" stopColor="#075c3a" />
        </linearGradient>
        <linearGradient id="anrat-blue" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#0a4a93" />
          <stop offset="100%" stopColor="#1878cf" />
        </linearGradient>
        <linearGradient id="anrat-red" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#e0323c" />
          <stop offset="100%" stopColor="#b5121f" />
        </linearGradient>
      </defs>

      <circle cx="66" cy="66" r="62" fill="#ffffff" />
      <g clipPath="url(#anrat-clip)">
        {/* bande verte inspirée du drapeau */}
        <path d="M4 20 C 21 44, 21 88, 4 112 L4 20 Z" fill="url(#anrat-green)" />
        <path
          d="M12 29 C 26 49, 26 83, 12 103"
          fill="none"
          stroke="#ffffff"
          strokeOpacity="0.35"
          strokeWidth="1.3"
        />

        {/* ondes télécom */}
        <g fill="none" stroke="#a7bccf" strokeWidth="1.4" strokeLinecap="round" opacity="0.9">
          <path d="M16 118 C 44 100, 70 54, 124 26" />
          <path d="M23 124 C 52 106, 78 62, 128 38" />
        </g>
        <g fill="none" stroke="#0c7a4d" strokeWidth="1.1" strokeLinecap="round" opacity="0.45">
          <path d="M32 128 C 62 110, 90 78, 128 58" />
          <path d="M42 130 C 72 114, 98 88, 130 72" />
        </g>

        {/* croissant et étoile */}
        <circle cx="47" cy="46" r="18" fill="url(#anrat-red)" mask="url(#anrat-crescent)" />
        <path
          d="M57 40.5 l 1.8 3.7 4.1 0.6 -3 2.9 0.7 4.1 -3.6 -2 -3.6 2 0.7 -4.1 -3 -2.9 4.1 -0.6 Z"
          fill="url(#anrat-red)"
        />

        {/* typographie */}
        <text
          x="88"
          y="82"
          textAnchor="middle"
          fontFamily="Segoe UI, Arial, Helvetica, sans-serif"
          fontSize="20"
          fontWeight="700"
          letterSpacing="0.6"
          fill="url(#anrat-blue)"
        >
          ANRAT
        </text>
        <line x1="57" y1="89" x2="121" y2="89" stroke="#17a55f" strokeWidth="1.5" strokeLinecap="round" />
        <text
          x="89"
          y="99"
          textAnchor="middle"
          fontFamily="Segoe UI, Arial, Helvetica, sans-serif"
          fontSize="4.7"
          fontWeight="700"
          letterSpacing="0.2"
          fill="#0c7a4d"
        >
          RETRAITÉS D&apos;ALGÉRIE TÉLÉCOM
        </text>
        <text
          x="89"
          y="107"
          textAnchor="middle"
          fontFamily="Segoe UI, Arial, Helvetica, sans-serif"
          fontSize="5"
          fill="#0a4a93"
        >
          ASSOCIATION NATIONALE
        </text>
      </g>
      <circle cx="66" cy="66" r="61" fill="none" stroke="#08243c" strokeWidth="2.2" />
      <circle cx="66" cy="66" r="56.5" fill="none" stroke="#d6e2ee" strokeWidth="0.8" />
    </svg>
  );
}

export function AnratWordmark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <AnratLogo className={compact ? "h-9 w-9" : "h-12 w-12"} />
      <div className="leading-tight">
        <div className="flex items-center gap-2">
          <span className="text-[1.35rem] font-extrabold tracking-tight text-at-navy">ANRAT</span>
          <span className="hidden rounded-full bg-at-green/10 px-2 py-0.5 text-[0.6rem] font-bold uppercase tracking-widest text-at-green sm:inline">
            Adhésion
          </span>
        </div>
        <p className="max-w-[19rem] text-[0.68rem] font-medium uppercase tracking-[0.14em] text-at-muted">
          Retraités d&apos;Algérie Télécom
        </p>
      </div>
    </div>
  );
}
