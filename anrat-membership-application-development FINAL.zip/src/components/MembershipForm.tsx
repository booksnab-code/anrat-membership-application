"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";
import { AnratLogo } from "./AnratLogo";
import { Icon, type IconName } from "./Icons";
import { MembershipCardPreview } from "./MembershipCardPreview";
import { compressPhoto, readFileAsDataUrl } from "@/lib/clientImage";
import { ASSOCIATION, BLOOD_TYPES, WILAYAS } from "@/lib/constants";
import { isReferenceFormat, normalizeReference } from "@/lib/references";
import { fieldErrors, membershipSchema } from "@/lib/validation";

type Draft = {
  lastName: string;
  firstName: string;
  birthDate: string;
  wilaya: string;
  bloodType: string;
  retirementDate: string;
  socialSecurityNumber: string;
  cnrNumber: string;
  mobile: string;
  email: string;
  photoData?: string;
  attachmentName?: string;
  attachmentType?: string;
  attachmentData?: string;
  consent: boolean;
};

type SubmitSuccess = {
  ok: true;
  reference: string;
  forward: {
    status: "non_configure" | "transmise" | "echec";
    channel: string | null;
    configured: boolean;
    delivered: boolean;
  };
  mailto: string;
  receiptUrl: string;
};

const EMPTY_DRAFT: Draft = {
  lastName: "",
  firstName: "",
  birthDate: "",
  wilaya: "",
  bloodType: "",
  retirementDate: "",
  socialSecurityNumber: "",
  cnrNumber: "",
  mobile: "",
  email: "",
  consent: false,
};

const FIELD_ORDER: Array<keyof Draft> = [
  "lastName",
  "firstName",
  "birthDate",
  "wilaya",
  "bloodType",
  "retirementDate",
  "socialSecurityNumber",
  "cnrNumber",
  "mobile",
  "email",
  "consent",
];

function SectionCard({
  index,
  title,
  subtitle,
  icon,
  children,
}: {
  index: string;
  title: string;
  subtitle: string;
  icon: IconName;
  children: ReactNode;
}) {
  return (
    <section className="print-card rounded-2xl border border-slate-200/90 bg-white p-5 sm:p-6">
      <header className="mb-5 flex items-start gap-3 border-b border-slate-100 pb-4">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-at-navy text-sm font-extrabold text-white">
          {index}
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="text-[0.98rem] font-bold text-at-navy">{title}</h3>
          <p className="mt-0.5 text-xs leading-relaxed text-at-muted">{subtitle}</p>
        </div>
        <Icon name={icon} className="hidden h-6 w-6 shrink-0 text-slate-300 sm:block" />
      </header>
      {children}
    </section>
  );
}

function Field({
  htmlFor,
  label,
  required,
  icon,
  error,
  hint,
  children,
}: {
  htmlFor?: string;
  label: string;
  required?: boolean;
  icon?: IconName;
  error?: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div>
      <label
        htmlFor={htmlFor}
        className="mb-1.5 flex items-center gap-1.5 text-[0.7rem] font-bold uppercase tracking-[0.1em] text-at-navy"
      >
        {icon ? <Icon name={icon} className="h-3.5 w-3.5 text-at-blue" /> : null}
        {label}
        {required ? (
          <span className="text-at-red" aria-hidden="true">
            *
          </span>
        ) : (
          <span className="text-[0.62rem] font-semibold normal-case tracking-normal text-slate-400">
            (facultatif)
          </span>
        )}
      </label>
      {children}
      {error ? (
        <p className="mt-1.5 flex items-start gap-1 text-[0.72rem] font-semibold leading-snug text-at-red">
          <Icon name="alert" className="mt-[1px] h-3.5 w-3.5 shrink-0" />
          {error}
        </p>
      ) : hint ? (
        <p className="mt-1.5 text-[0.72rem] leading-snug text-at-muted">{hint}</p>
      ) : null}
    </div>
  );
}

export function MembershipForm() {
  const [draft, setDraft] = useState<Draft>(EMPTY_DRAFT);
  const [photoName, setPhotoName] = useState<string>("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");
  const [globalError, setGlobalError] = useState<string | null>(null);
  const [result, setResult] = useState<SubmitSuccess | null>(null);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [attachmentBusy, setAttachmentBusy] = useState(false);
  const [trackingValue, setTrackingValue] = useState("");
  const [trackingError, setTrackingError] = useState<string | null>(null);
  const successRef = useRef<HTMLDivElement | null>(null);
  const router = useRouter();

  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const maxBirthDate = useMemo(() => {
    const date = new Date();
    date.setFullYear(date.getFullYear() - 40);
    return date.toISOString().slice(0, 10);
  }, []);

  useEffect(() => {
    if (status === "success" && successRef.current) {
      successRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [status]);

  function setField<K extends keyof Draft>(key: K, value: Draft[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
    setErrors((current) => {
      if (!current[key as string]) return current;
      const next = { ...current };
      delete next[key as string];
      return next;
    });
  }

  async function handlePhoto(event: ChangeEvent<HTMLInputElement>) {
    const input = event.target;
    const file = input.files?.[0];
    input.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setErrors((current) => ({ ...current, photoData: "Choisissez une image (JPG, PNG ou WEBP)." }));
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setErrors((current) => ({ ...current, photoData: "La photo ne doit pas dépasser 8 Mo." }));
      return;
    }
    setPhotoBusy(true);
    try {
      const data = await compressPhoto(file);
      setPhotoName(file.name);
      setField("photoData", data);
    } catch (error) {
      setErrors((current) => ({
        ...current,
        photoData: error instanceof Error ? error.message : "Photo illisible.",
      }));
    } finally {
      setPhotoBusy(false);
    }
  }

  async function handleAttachment(event: ChangeEvent<HTMLInputElement>) {
    const input = event.target;
    const file = input.files?.[0];
    input.value = "";
    if (!file) return;
    const allowed = ["application/pdf", "image/jpeg", "image/png", "image/webp"];
    if (!allowed.includes(file.type)) {
      setErrors((current) => ({
        ...current,
        attachmentData: "Formats acceptés : PDF, JPG, PNG ou WEBP.",
      }));
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setErrors((current) => ({
        ...current,
        attachmentData: "La pièce jointe ne doit pas dépasser 2 Mo.",
      }));
      return;
    }
    setAttachmentBusy(true);
    try {
      const data = await readFileAsDataUrl(file);
      if (data.length > 2_800_000) {
        setErrors((current) => ({
          ...current,
          attachmentData: "Fichier trop volumineux après encodage. Choisissez un fichier plus léger.",
        }));
        return;
      }
      setDraft((current) => ({
        ...current,
        attachmentName: file.name,
        attachmentType: file.type,
        attachmentData: data,
      }));
      setErrors((current) => {
        const next = { ...current };
        delete next.attachmentData;
        return next;
      });
    } catch {
      setErrors((current) => ({ ...current, attachmentData: "Lecture du fichier impossible." }));
    } finally {
      setAttachmentBusy(false);
    }
  }

  function removeAttachment() {
    setDraft((current) => ({
      ...current,
      attachmentName: undefined,
      attachmentType: undefined,
      attachmentData: undefined,
    }));
  }

  function handlePrint() {
    if (typeof window !== "undefined") window.print();
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (status === "submitting") return;

    const payload = {
      ...draft,
      photoData: draft.photoData || undefined,
      attachmentName: draft.attachmentName || undefined,
      attachmentType: draft.attachmentType || undefined,
      attachmentData: draft.attachmentData || undefined,
    };

    const parsed = membershipSchema.safeParse(payload);
    if (!parsed.success) {
      const nextErrors = fieldErrors(parsed.error);
      setErrors(nextErrors);
      setGlobalError("Merci de corriger les champs signalés avant d'envoyer votre demande.");
      const firstKey = FIELD_ORDER.find((key) => nextErrors[key]);
      if (firstKey) {
        document.getElementById(String(firstKey))?.scrollIntoView({ behavior: "smooth", block: "center" });
      }
      return;
    }

    setErrors({});
    setGlobalError(null);
    setStatus("submitting");

    try {
      const response = await fetch("/api/adhesions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as
        | SubmitSuccess
        | { ok: false; error?: string; fieldErrors?: Record<string, string> };

      if (!response.ok || !("ok" in data) || data.ok !== true) {
        const failure = data as { ok: false; error?: string; fieldErrors?: Record<string, string> };
        setErrors(failure.fieldErrors ?? {});
        setGlobalError(failure.error ?? "L'envoi a échoué. Merci de réessayer dans un instant.");
        setStatus("idle");
        return;
      }

      setResult(data);
      setStatus("success");
    } catch {
      setGlobalError(
        "Connexion au serveur impossible. Vérifiez votre connexion Internet puis réessayez.",
      );
      setStatus("idle");
    }
  }

  function startNew() {
    setDraft(EMPTY_DRAFT);
    setPhotoName("");
    setErrors({});
    setGlobalError(null);
    setResult(null);
    setStatus("idle");
    document.getElementById("adhesion")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  if (status === "success" && result) {
    const delivered = result.forward.status === "transmise";
    return (
      <div id="adhesion" ref={successRef} className="scroll-mt-24">
        <div className="overflow-hidden rounded-3xl border border-at-green/25 bg-white shadow-card">
          <div className="relative overflow-hidden bg-gradient-to-br from-at-green via-at-green to-at-navy px-6 py-8 text-white sm:px-9">
            <div className="grid-pattern pointer-events-none absolute inset-0 opacity-60" aria-hidden="true" />
            <div className="relative flex flex-col items-start gap-4 sm:flex-row sm:items-center">
              <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/15 ring-1 ring-white/30">
                <Icon name="checkCircle" className="h-8 w-8" strokeWidth={1.9} />
              </span>
              <div>
                <p className="text-[0.65rem] font-bold uppercase tracking-[0.2em] text-white/75">
                  Confirmation d&apos;envoi
                </p>
                <h2 className="mt-1 text-2xl font-extrabold tracking-tight">
                  Votre demande a été transmise à notre association
                </h2>
                <p className="mt-2 max-w-xl text-sm leading-relaxed text-white/85">
                  Merci {draft.firstName || "cher(e) adhérent(e)"} ! Notre association a bien reçu votre
                  demande d&apos;adhésion ANRAT. Vous serez contacté(e) au {draft.mobile || "numéro indiqué"}{" "}
                  pour la remise de votre carte d&apos;adhésion.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-6 p-6 sm:p-9">
            <div className="flex flex-col gap-3 rounded-2xl border border-dashed border-at-blue/30 bg-at-blue/5 p-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-[0.65rem] font-bold uppercase tracking-[0.16em] text-at-muted">
                  Référence de votre demande
                </p>
                <p className="mt-1 font-mono text-lg font-bold tracking-wider text-at-navy">
                  {result.reference}
                </p>
              </div>
              <div className="flex items-center gap-2 text-xs font-semibold">
                <span
                  className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 ${
                    delivered ? "bg-at-green/12 text-at-green" : "bg-amber-100 text-amber-800"
                  }`}
                >
                  <Icon name={delivered ? "checkCircle" : "clock"} className="h-3.5 w-3.5" />
                  {delivered
                    ? `Transmise · ${result.forward.channel ?? "canal sécurisé"}`
                    : "Enregistrée — en attente de synchronisation"}
                </span>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-bold text-at-navy">Récapitulatif de votre demande</h3>
              <dl className="mt-3 grid gap-x-6 gap-y-3 sm:grid-cols-2">
                {[
                  ["Nom et prénom", `${draft.lastName.toUpperCase()} ${draft.firstName}`],
                  ["Date de naissance", draft.birthDate],
                  ["Wilaya de résidence", draft.wilaya],
                  ["Rhésus sanguin", draft.bloodType || "—"],
                  ["Départ à la retraite", draft.retirementDate],
                  ["N° sécurité sociale", draft.socialSecurityNumber],
                  ["N° CNR", draft.cnrNumber],
                  ["Mobile", draft.mobile],
                  ["E-mail", draft.email],
                  ["Pièce jointe", draft.attachmentName || "Aucune"],
                ].map(([label, value]) => (
                  <div key={label} className="flex justify-between gap-3 border-b border-slate-100 pb-2">
                    <dt className="text-xs text-at-muted">{label}</dt>
                    <dd className="text-right text-xs font-semibold text-at-navy">{value || "—"}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="rounded-2xl bg-slate-50 p-4 text-xs leading-relaxed text-slate-600">
              <p className="flex items-start gap-2">
                <Icon name="info" className="mt-0.5 h-4 w-4 shrink-0 text-at-blue" />
                <span>
                  Votre demande est conservée auprès de l&apos;ANRAT et destinée à la confection de votre carte
                  d&apos;adhésion. Pour toute question, écrivez-nous à{" "}
                  <a className="font-semibold text-at-blue underline" href={`mailto:${ASSOCIATION.email}`}>
                    {ASSOCIATION.email}
                  </a>
                  {delivered
                    ? " en rappelant votre référence."
                    : " : vous pouvez aussi nous transmettre ce récapitulatif directement par e-mail."}
                </span>
              </p>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
              <Link
                href={result.receiptUrl}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-at-blue px-5 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-at-navy"
              >
                <Icon name="printer" className="h-4 w-4" />
                Voir et imprimer mon récapitulatif
              </Link>
              {!delivered ? (
                <a
                  href={result.mailto}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-at-green/40 bg-at-green/5 px-5 py-3 text-sm font-bold text-at-green transition hover:bg-at-green/10"
                >
                  <Icon name="mail" className="h-4 w-4" />
                  Transmettre par e-mail à l&apos;association
                </a>
              ) : null}
              <button
                type="button"
                onClick={startNew}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 px-5 py-3 text-sm font-bold text-slate-600 transition hover:border-at-blue/40 hover:text-at-blue"
              >
                <Icon name="user" className="h-4 w-4" />
                Déposer une autre demande
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div id="adhesion" className="scroll-mt-24">
      <div className="mb-5 flex flex-wrap items-center gap-2 no-print">
        {[
          { icon: "user" as IconName, label: "Informations personnelles" },
          { icon: "wallet" as IconName, label: "Retraite & santé" },
          { icon: "phone" as IconName, label: "Contact & pièces" },
        ].map((step, index) => (
          <span
            key={step.label}
            className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-[0.7rem] font-semibold text-slate-600"
          >
            <span className="grid h-4 w-4 place-items-center rounded-full bg-at-blue/10 text-[0.6rem] font-bold text-at-blue">
              {index + 1}
            </span>
            {step.label}
          </span>
        ))}
        <span className="ml-auto hidden items-center gap-1.5 text-[0.7rem] font-semibold text-at-green sm:inline-flex">
          <Icon name="clock" className="h-3.5 w-3.5" />
          Environ 2 minutes
        </span>
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_330px] lg:items-start">
      <form onSubmit={handleSubmit} noValidate>
        <div
          id="print-sheet"
          className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-card"
        >
          {/* En-tête imprimable */}
          <div className="print-only border-b-2 border-at-navy pb-3">
            <div className="flex items-center gap-3">
              <AnratLogo className="h-16 w-16" />
              <div className="flex-1">
                <p className="text-[9px] font-bold uppercase tracking-[0.14em] text-at-green">
                  {ASSOCIATION.longName}
                </p>
                <h2 className="text-lg font-extrabold text-at-navy">FORMULAIRE D&apos;ADHÉSION ANRAT</h2>
                <p className="text-[9px] text-at-muted">
                  Document à remettre à l&apos;association pour la confection de la carte d&apos;adhésion
                </p>
              </div>
              <div className="text-right text-[9px] text-at-muted">
                <p>Date : {new Date().toLocaleDateString("fr-FR")}</p>
                <p>Référence : ................................</p>
              </div>
            </div>
          </div>

          {/* En-tête écran */}
          <div className="no-print border-b border-slate-100 bg-gradient-to-br from-slate-50 to-white px-6 py-6 sm:px-8">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <span className="inline-flex items-center gap-2 rounded-full bg-at-green/10 px-3 py-1 text-[0.62rem] font-bold uppercase tracking-[0.16em] text-at-green">
                  <Icon name="badgeCheck" className="h-3.5 w-3.5" />
                  Formulaire officiel
                </span>
                <h2 className="mt-3 text-2xl font-extrabold tracking-tight text-at-navy sm:text-[1.7rem]">
                  Demande d&apos;adhésion ANRAT
                </h2>
                <p className="mt-2 max-w-xl text-sm leading-relaxed text-slate-600">
                  Bienvenue ! Que vous soyez nouvellement retraité ou déjà membre de notre famille, rejoignez
                  l&apos;ANRAT en quelques minutes. Renseignez les informations ci-dessous : elles servent
                  uniquement à la confection de votre carte d&apos;adhésion.
                </p>
              </div>
              <div className="hidden shrink-0 items-center gap-2 rounded-xl border border-slate-200 bg-white p-2.5 sm:flex">
                <AnratLogo className="h-11 w-11" />
                <div className="text-[0.62rem] leading-tight">
                  <p className="font-extrabold tracking-wide text-at-navy">ANRAT</p>
                  <p className="text-at-muted">Carte d&apos;adhésion</p>
                  <p className="font-semibold text-at-green">Édition 2026</p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6 p-5 sm:p-8">
            {globalError ? (
              <div
                role="alert"
                className="no-print flex items-start gap-2 rounded-xl border border-at-red/25 bg-at-red/5 p-3.5 text-sm font-medium text-at-red"
              >
                <Icon name="alert" className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{globalError}</span>
              </div>
            ) : null}

            <SectionCard
              index="I"
              title="Informations personnelles"
              subtitle="Identité du retraité, telle qu'elle figurera sur la carte d'adhésion."
              icon="user"
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <Field htmlFor="lastName" label="Nom" required icon="user" error={errors.lastName}>
                  <input
                    id="lastName"
                    name="lastName"
                    type="text"
                    autoComplete="family-name"
                    placeholder="Ex : BENALI"
                    className="field-input uppercase"
                    value={draft.lastName}
                    aria-invalid={errors.lastName ? true : undefined}
                    onChange={(event) => setField("lastName", event.target.value.toUpperCase())}
                  />
                </Field>

                <Field htmlFor="firstName" label="Prénom" required icon="user" error={errors.firstName}>
                  <input
                    id="firstName"
                    name="firstName"
                    type="text"
                    autoComplete="given-name"
                    placeholder="Ex : Mohamed"
                    className="field-input"
                    value={draft.firstName}
                    aria-invalid={errors.firstName ? true : undefined}
                    onChange={(event) => setField("firstName", event.target.value)}
                  />
                </Field>

                <Field
                  htmlFor="birthDate"
                  label="Date de naissance"
                  required
                  icon="calendar"
                  error={errors.birthDate}
                >
                  <input
                    id="birthDate"
                    name="birthDate"
                    type="date"
                    className="field-input"
                    value={draft.birthDate}
                    max={maxBirthDate}
                    min="1920-01-01"
                    aria-invalid={errors.birthDate ? true : undefined}
                    onChange={(event) => setField("birthDate", event.target.value)}
                  />
                </Field>

                <Field
                  htmlFor="wilaya"
                  label="Wilaya de résidence"
                  required
                  icon="mapPin"
                  error={errors.wilaya}
                >
                  <select
                    id="wilaya"
                    name="wilaya"
                    className="field-input"
                    value={draft.wilaya}
                    aria-invalid={errors.wilaya ? true : undefined}
                    onChange={(event) => setField("wilaya", event.target.value)}
                  >
                    <option value="">Sélectionnez votre wilaya</option>
                    {WILAYAS.map((wilaya) => (
                      <option key={wilaya.code} value={wilaya.name}>
                        {wilaya.code} — {wilaya.name}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field
                  htmlFor="bloodType"
                  label="Rhésus sanguin"
                  required
                  icon="droplet"
                  error={errors.bloodType}
                  hint="Utile pour l'assistance et les urgences lors des activités de l'association."
                >
                  <select
                    id="bloodType"
                    name="bloodType"
                    className="field-input"
                    value={draft.bloodType}
                    aria-invalid={errors.bloodType ? true : undefined}
                    onChange={(event) => setField("bloodType", event.target.value)}
                  >
                    <option value="">Sélectionnez votre groupe sanguin</option>
                    {BLOOD_TYPES.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>
            </SectionCard>

            <SectionCard
              index="II"
              title="Informations de retraite & santé"
              subtitle="Références professionnelles permettant de vérifier votre qualité de retraité d'Algérie Télécom."
              icon="wallet"
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <Field
                  htmlFor="retirementDate"
                  label="Date de départ à la retraite"
                  required
                  icon="calendar"
                  error={errors.retirementDate}
                >
                  <input
                    id="retirementDate"
                    name="retirementDate"
                    type="date"
                    className="field-input"
                    value={draft.retirementDate}
                    max={today}
                    min="1950-01-01"
                    aria-invalid={errors.retirementDate ? true : undefined}
                    onChange={(event) => setField("retirementDate", event.target.value)}
                  />
                </Field>

                <Field
                  htmlFor="socialSecurityNumber"
                  label="Numéro de sécurité sociale (SS)"
                  required
                  icon="idCard"
                  error={errors.socialSecurityNumber}
                  hint="Chiffres uniquement, sans espaces."
                >
                  <input
                    id="socialSecurityNumber"
                    name="socialSecurityNumber"
                    type="text"
                    inputMode="numeric"
                    autoComplete="off"
                    placeholder="Ex : 160012345678"
                    className="field-input font-mono tracking-wide"
                    value={draft.socialSecurityNumber}
                    aria-invalid={errors.socialSecurityNumber ? true : undefined}
                    onChange={(event) =>
                      setField("socialSecurityNumber", event.target.value.replace(/[^\d\s.-]/g, ""))
                    }
                  />
                </Field>

                <Field
                  htmlFor="cnrNumber"
                  label="Numéro caisse nationale de retraite (CNR)"
                  required
                  icon="wallet"
                  error={errors.cnrNumber}
                  hint="Numéro figurant sur votre attestation CNR."
                >
                  <input
                    id="cnrNumber"
                    name="cnrNumber"
                    type="text"
                    autoComplete="off"
                    placeholder="Ex : 2022/160000123"
                    className="field-input font-mono tracking-wide"
                    value={draft.cnrNumber}
                    aria-invalid={errors.cnrNumber ? true : undefined}
                    onChange={(event) => setField("cnrNumber", event.target.value.toUpperCase())}
                  />
                </Field>

                <div className="no-print flex items-start gap-2 rounded-xl bg-at-blue/5 p-3.5 text-[0.72rem] leading-relaxed text-slate-600">
                  <Icon name="shield" className="mt-0.5 h-4 w-4 shrink-0 text-at-blue" />
                  <span>
                    Ces numéros sont contrôlés par les services de l&apos;association uniquement dans le cadre
                    de votre adhésion. Ils ne sont jamais publiés ni partagés avec des tiers.
                  </span>
                </div>
              </div>
            </SectionCard>

            <SectionCard
              index="III"
              title="Contact personnel & pièces jointes"
              subtitle="Pour vous joindre rapidement et compléter votre dossier d'adhésion."
              icon="phone"
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <Field htmlFor="mobile" label="Numéro mobile" required icon="phone" error={errors.mobile}>
                  <input
                    id="mobile"
                    name="mobile"
                    type="tel"
                    inputMode="tel"
                    autoComplete="tel"
                    placeholder="Ex : 0550123456"
                    className="field-input font-mono tracking-wide"
                    value={draft.mobile}
                    aria-invalid={errors.mobile ? true : undefined}
                    onChange={(event) =>
                      setField("mobile", event.target.value.replace(/[^\d\s.+-]/g, "").slice(0, 16))
                    }
                  />
                </Field>

                <Field htmlFor="email" label="Adresse e-mail" required icon="mail" error={errors.email}>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    placeholder="Ex : mohamed.benali@example.dz"
                    className="field-input"
                    value={draft.email}
                    aria-invalid={errors.email ? true : undefined}
                    onChange={(event) => setField("email", event.target.value)}
                  />
                </Field>
              </div>

              <div className="print-hide mt-5 grid gap-4 sm:grid-cols-2">
                <div>
                  <p className="mb-1.5 flex items-center gap-1.5 text-[0.7rem] font-bold uppercase tracking-[0.1em] text-at-navy">
                    <Icon name="camera" className="h-3.5 w-3.5 text-at-blue" />
                    Photo d&apos;identité
                    <span className="text-[0.62rem] font-semibold normal-case tracking-normal text-slate-400">
                      (facultatif)
                    </span>
                  </p>
                  <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-3">
                    {draft.photoData ? (
                      <div className="flex items-center gap-3">
                        <span className="h-16 w-[52px] overflow-hidden rounded-lg border border-slate-200 bg-white">
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img
                            src={draft.photoData}
                            alt="Aperçu de la photo d'identité"
                            className="h-full w-full object-cover"
                          />
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-xs font-semibold text-at-navy">{photoName}</p>
                          <p className="text-[0.68rem] text-at-muted">Photo prête pour la carte</p>
                          <button
                            type="button"
                            onClick={() => {
                              setField("photoData", undefined);
                              setPhotoName("");
                            }}
                            className="mt-1 inline-flex items-center gap-1 text-[0.7rem] font-bold text-at-red hover:underline"
                          >
                            <Icon name="close" className="h-3 w-3" />
                            Retirer
                          </button>
                        </div>
                      </div>
                    ) : (
                      <label
                        htmlFor="photo"
                        className="flex cursor-pointer items-center gap-3 text-slate-600 hover:text-at-blue"
                      >
                        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-white text-at-blue ring-1 ring-slate-200">
                          <Icon name={photoBusy ? "clock" : "upload"} className="h-5 w-5" />
                        </span>
                        <span className="text-xs leading-snug">
                          <span className="block font-semibold text-at-navy">
                            {photoBusy ? "Traitement en cours…" : "Ajouter une photo"}
                          </span>
                          JPG ou PNG — max 8 Mo. Non imprimée sur le formulaire.
                        </span>
                      </label>
                    )}
                    <input
                      id="photo"
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="sr-only"
                      onChange={handlePhoto}
                    />
                  </div>
                  {errors.photoData ? (
                    <p className="mt-1.5 flex items-start gap-1 text-[0.72rem] font-semibold text-at-red">
                      <Icon name="alert" className="mt-[1px] h-3.5 w-3.5 shrink-0" />
                      {errors.photoData}
                    </p>
                  ) : null}
                </div>

                <div>
                  <p className="mb-1.5 flex items-center gap-1.5 text-[0.7rem] font-bold uppercase tracking-[0.1em] text-at-navy">
                    <Icon name="file" className="h-3.5 w-3.5 text-at-blue" />
                    Pièce jointe
                    <span className="text-[0.62rem] font-semibold normal-case tracking-normal text-slate-400">
                      (facultatif)
                    </span>
                  </p>
                  <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-3">
                    {draft.attachmentName ? (
                      <div className="flex items-center gap-3">
                        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-at-green/10 text-at-green">
                          <Icon name="file" className="h-5 w-5" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-xs font-semibold text-at-navy">{draft.attachmentName}</p>
                          <p className="text-[0.68rem] text-at-muted">Pièce jointe au dossier</p>
                          <button
                            type="button"
                            onClick={removeAttachment}
                            className="mt-1 inline-flex items-center gap-1 text-[0.7rem] font-bold text-at-red hover:underline"
                          >
                            <Icon name="close" className="h-3 w-3" />
                            Retirer
                          </button>
                        </div>
                      </div>
                    ) : (
                      <label
                        htmlFor="attachment"
                        className="flex cursor-pointer items-center gap-3 text-slate-600 hover:text-at-blue"
                      >
                        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-white text-at-blue ring-1 ring-slate-200">
                          <Icon name={attachmentBusy ? "clock" : "upload"} className="h-5 w-5" />
                        </span>
                        <span className="text-xs leading-snug">
                          <span className="block font-semibold text-at-navy">
                            {attachmentBusy ? "Chargement…" : "Joindre un justificatif"}
                          </span>
                          Attestation de retraite, CNR… PDF/JPG — max 2 Mo.
                        </span>
                      </label>
                    )}
                    <input
                      id="attachment"
                      type="file"
                      accept="application/pdf,image/jpeg,image/png,image/webp"
                      className="sr-only"
                      onChange={handleAttachment}
                    />
                  </div>
                  {errors.attachmentData ? (
                    <p className="mt-1.5 flex items-start gap-1 text-[0.72rem] font-semibold text-at-red">
                      <Icon name="alert" className="mt-[1px] h-3.5 w-3.5 shrink-0" />
                      {errors.attachmentData}
                    </p>
                  ) : null}
                </div>
              </div>
            </SectionCard>

            <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4 sm:p-5">
              <label htmlFor="consent" className="flex cursor-pointer items-start gap-3">
                <input
                  id="consent"
                  name="consent"
                  type="checkbox"
                  checked={draft.consent}
                  onChange={(event) => setField("consent", event.target.checked)}
                  className="mt-0.5 h-5 w-5 shrink-0 rounded border-slate-300 text-at-blue accent-[#0b4f9e]"
                  aria-invalid={errors.consent ? true : undefined}
                />
                <span className="text-xs leading-relaxed text-slate-600">
                  Je certifie l&apos;exactitude des informations fournies et j&apos;accepte que l&apos;ANRAT
                  les utilise exclusivement pour la confection de ma carte d&apos;adhésion et la gestion de la
                  vie associative. <span className="font-semibold text-at-navy">Champ obligatoire.</span>
                </span>
              </label>
              {errors.consent ? (
                <p className="mt-2 flex items-start gap-1 text-[0.72rem] font-semibold text-at-red">
                  <Icon name="alert" className="mt-[1px] h-3.5 w-3.5 shrink-0" />
                  {errors.consent}
                </p>
              ) : null}
            </div>

            <div className="no-print flex flex-col gap-3 border-t border-slate-100 pt-5 sm:flex-row sm:items-center sm:justify-between">
              <p className="order-2 flex items-center gap-1.5 text-[0.7rem] text-at-muted sm:order-1">
                <Icon name="lock" className="h-3.5 w-3.5 text-at-green" />
                Transmission sécurisée vers le dossier de l&apos;association
              </p>
              <div className="order-1 flex flex-col gap-2.5 sm:order-2 sm:flex-row">
                <button
                  type="button"
                  onClick={handlePrint}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-at-navy/20 bg-white px-5 py-3 text-sm font-bold text-at-navy shadow-sm transition hover:border-at-navy/40 hover:bg-slate-50"
                >
                  <Icon name="printer" className="h-4 w-4" />
                  Imprimer le formulaire
                </button>
                <button
                  type="submit"
                  disabled={status === "submitting"}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-at-blue px-6 py-3 text-sm font-bold text-white shadow-[0_10px_24px_-10px_rgba(11,79,158,0.9)] transition hover:bg-at-navy disabled:cursor-not-allowed disabled:opacity-70"
                >
                  {status === "submitting" ? (
                    <>
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
                      Envoi en cours…
                    </>
                  ) : (
                    <>
                      <Icon name="send" className="h-4 w-4" />
                      Envoyer ma demande
                    </>
                  )}
                </button>
              </div>
            </div>
            <p className="no-print text-center text-[0.68rem] text-at-muted sm:text-left">
              L&apos;impression du formulaire se fait <strong>sans la photo</strong> et sans vos pièces
              jointes, pour un dépôt physique auprès de l&apos;association.
            </p>

            <div className="print-only mt-6 border-t border-slate-300 pt-4 text-[9px] text-slate-600">
              <div className="flex justify-between gap-6">
                <p>Signature de l&apos;adhérent : ................................................</p>
                <p>Cachet de l&apos;association : ................................................</p>
              </div>
              <p className="mt-3 text-center">
                ANRAT — {ASSOCIATION.longName} · {ASSOCIATION.email} · Informations destinées à la confection
                de la carte d&apos;adhésion.
              </p>
            </div>
          </div>
        </div>
      </form>

        <aside className="no-print space-y-4 lg:sticky lg:top-24">
          <MembershipCardPreview
            firstName={draft.firstName}
            lastName={draft.lastName}
            wilaya={draft.wilaya}
            bloodType={draft.bloodType}
            photoData={draft.photoData}
          />

          <div id="suivi" className="scroll-mt-24 rounded-2xl border border-slate-200 bg-white p-4 shadow-soft">
            <h3 className="flex items-center gap-2 text-sm font-bold text-at-navy">
              <Icon name="search" className="h-4 w-4 text-at-blue" />
              Suivre ma demande
            </h3>
            <p className="mt-1 text-[0.72rem] leading-relaxed text-at-muted">
              Saisissez la référence reçue lors de l&apos;envoi pour consulter l&apos;état de votre adhésion.
            </p>
            <form
              className="mt-3 flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                const value = normalizeReference(trackingValue);
                if (!isReferenceFormat(value)) {
                  setTrackingError("Référence invalide. Exemple : ANRAT-2026-00042");
                  return;
                }
                setTrackingError(null);
                router.push(`/adhesion/${encodeURIComponent(value)}`);
              }}
            >
              <input
                type="text"
                value={trackingValue}
                onChange={(event) => setTrackingValue(event.target.value)}
                placeholder="ANRAT-2026-00042"
                aria-label="Référence de la demande"
                className="field-input font-mono text-xs uppercase"
              />
              <button
                type="submit"
                aria-label="Rechercher ma demande"
                className="grid h-[42px] w-[42px] shrink-0 place-items-center rounded-xl bg-at-navy text-white transition hover:bg-at-blue"
              >
                <Icon name="arrowRight" className="h-4 w-4" />
              </button>
            </form>
            {trackingError ? (
              <p className="mt-1.5 text-[0.7rem] font-semibold text-at-red">{trackingError}</p>
            ) : null}
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-soft">
            <div className="flex items-center gap-2 border-b border-slate-100 bg-gradient-to-r from-at-green/8 to-transparent px-4 py-3">
              <Icon name="shield" className="h-4 w-4 text-at-green" />
              <h3 className="text-sm font-bold text-at-navy">Vos données, en toute confiance</h3>
            </div>
            <ul className="space-y-2.5 p-4 text-[0.74rem] leading-relaxed text-slate-600">
              <li className="flex gap-2">
                <Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-at-green" />
                Informations utilisées uniquement pour la carte d&apos;adhésion et le suivi de votre dossier.
              </li>
              <li className="flex gap-2">
                <Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-at-green" />
                Aucune donnée n&apos;est publique ou partagée avec un tiers.
              </li>
              <li className="flex gap-2">
                <Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-at-green" />
                Vous pouvez demander la rectification de vos informations à tout moment.
              </li>
            </ul>
            <div className="border-t border-slate-100 bg-slate-50/70 px-4 py-3 text-[0.72rem] text-slate-600">
              <p className="font-semibold text-at-navy">Une question ?</p>
              <a
                href={`mailto:${ASSOCIATION.email}`}
                className="mt-1 inline-flex items-center gap-1.5 font-semibold text-at-blue hover:underline"
              >
                <Icon name="mail" className="h-3.5 w-3.5" />
                {ASSOCIATION.email}
              </a>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
