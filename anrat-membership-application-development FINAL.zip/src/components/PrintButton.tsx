"use client";

import { Icon } from "./Icons";

export function PrintButton({
  label = "Imprimer",
  className = "inline-flex items-center justify-center gap-2 rounded-xl bg-at-blue px-5 py-3 text-sm font-bold text-white transition hover:bg-at-navy",
}: {
  label?: string;
  className?: string;
}) {
  return (
    <button type="button" onClick={() => window.print()} className={`no-print ${className}`}>
      <Icon name="printer" className="h-4 w-4" />
      {label}
    </button>
  );
}
