import Link from "next/link";
import { AnratWordmark } from "./AnratLogo";
import { Icon } from "./Icons";
import { ASSOCIATION } from "@/lib/constants";

export function SiteHeader({ active = "adhesion" }: { active?: "adhesion" | "suivi" | "admin" }) {
  return (
    <header className="no-print sticky top-0 z-40 border-b border-slate-200/80 bg-white/90 backdrop-blur">
      <div className="brand-rule h-1 w-full" aria-hidden="true" />
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <Link href="/" className="shrink-0" aria-label="Accueil ANRAT">
          <AnratWordmark />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Navigation principale">
          <Link
            href="/#adhesion"
            className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
              active === "adhesion" ? "bg-at-blue/8 text-at-blue" : "text-slate-600 hover:bg-slate-100"
            }`}
          >
            Formulaire d&apos;adhésion
          </Link>
          <Link
            href="/#suivi"
            className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
              active === "suivi" ? "bg-at-blue/8 text-at-blue" : "text-slate-600 hover:bg-slate-100"
            }`}
          >
            Suivre ma demande
          </Link>
          <a
            href={`mailto:${ASSOCIATION.email}`}
            className="rounded-full px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100"
          >
            Nous contacter
          </a>
        </nav>

        <div className="flex items-center gap-2">
          <Link
            href="/admin"
            className="hidden items-center gap-2 rounded-full border border-slate-200 px-3.5 py-2 text-xs font-semibold text-slate-600 transition hover:border-at-blue/40 hover:text-at-blue sm:flex"
          >
            <Icon name="lock" className="h-3.5 w-3.5" />
            Espace association
          </Link>
          <Link
            href="/#adhesion"
            className="inline-flex items-center gap-2 rounded-full bg-at-blue px-4 py-2.5 text-xs font-bold uppercase tracking-wide text-white shadow-sm transition hover:bg-at-navy"
          >
            Adhérer
            <Icon name="arrowRight" className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="no-print mt-16 border-t border-slate-200 bg-white">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <AnratWordmark compact />
          <p className="mt-3 max-w-sm text-sm leading-relaxed text-slate-600">
            {ASSOCIATION.longName}. Au service des retraités d&apos;Algérie Télécom, pour la solidarité,
            l&apos;entraide et la valorisation du lien entre les générations.
          </p>
          <p className="mt-3 text-xs font-semibold uppercase tracking-[0.16em] text-at-green">
            {ASSOCIATION.longNameAr}
          </p>
        </div>
        <div>
          <h3 className="text-xs font-bold uppercase tracking-[0.16em] text-at-navy">Adhésion</h3>
          <ul className="mt-3 space-y-2 text-sm text-slate-600">
            <li>
              <Link href="/#adhesion" className="hover:text-at-blue">
                Formulaire d&apos;adhésion
              </Link>
            </li>
            <li>
              <Link href="/#suivi" className="hover:text-at-blue">
                Suivre ma demande
              </Link>
            </li>
            <li>
              <Link href="/admin" className="hover:text-at-blue">
                Espace association
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h3 className="text-xs font-bold uppercase tracking-[0.16em] text-at-navy">Contact</h3>
          <ul className="mt-3 space-y-2 text-sm text-slate-600">
            <li className="flex items-center gap-2">
              <Icon name="mail" className="h-4 w-4 text-at-blue" />
              <a href={`mailto:${ASSOCIATION.email}`} className="hover:text-at-blue">
                {ASSOCIATION.email}
              </a>
            </li>
            <li className="flex items-start gap-2">
              <Icon name="building" className="mt-0.5 h-4 w-4 text-at-blue" />
              <span>Algérie Télécom — Direction générale, Alger</span>
            </li>
            <li className="flex items-start gap-2">
              <Icon name="shield" className="mt-0.5 h-4 w-4 text-at-green" />
              <span>Vos données servent uniquement à la carte d&apos;adhésion.</span>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-slate-100">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs text-slate-500 sm:flex-row sm:px-6">
          <p>© {new Date().getFullYear()} ANRAT — {ASSOCIATION.longName}. Tous droits réservés.</p>
          <p className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-at-green" />
            Formulaire officiel d&apos;adhésion en ligne
          </p>
        </div>
      </div>
    </footer>
  );
}
