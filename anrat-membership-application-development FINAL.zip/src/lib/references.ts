export function referenceFor(id: number, date = new Date()): string {
  return `ANRAT-${date.getUTCFullYear()}-${String(id).padStart(5, "0")}`;
}

export function normalizeReference(input: string): string {
  return input.trim().toUpperCase().replace(/\s+/g, "");
}

export function isReferenceFormat(input: string): boolean {
  return /^ANRAT-\d{4}-\d{3,8}$/.test(normalizeReference(input));
}
