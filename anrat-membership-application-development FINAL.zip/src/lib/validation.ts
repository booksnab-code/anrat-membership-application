import { z } from "zod";
import { BLOOD_TYPES, WILAYAS } from "./constants";

const NAME_REGEX = /^[\p{L}\s'’.-]{2,70}$/u;
const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/;

function isValidDate(value: string): boolean {
  if (!DATE_REGEX.test(value)) return false;
  const date = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

const MAX_PHOTO_CHARS = 1_400_000; // ~1 Mo en base64
const MAX_ATTACHMENT_CHARS = 2_800_000; // ~2 Mo en base64

const dataUrl = (allowed: string[]) =>
  z
    .string()
    .max(4_000_000)
    .refine(
      (value) => value === "" || allowed.some((prefix) => value.startsWith(prefix)),
      "Format de fichier non autorisé.",
    );

export const membershipSchema = z
  .object({
    lastName: z
      .string()
      .trim()
      .min(2, "Le nom doit contenir au moins 2 caractères.")
      .max(70, "Le nom est trop long.")
      .regex(NAME_REGEX, "Le nom contient des caractères non autorisés."),
    firstName: z
      .string()
      .trim()
      .min(2, "Le prénom doit contenir au moins 2 caractères.")
      .max(70, "Le prénom est trop long.")
      .regex(NAME_REGEX, "Le prénom contient des caractères non autorisés."),
    birthDate: z
      .string()
      .refine(isValidDate, "Renseignez une date de naissance valide.")
      .refine((value) => {
        const year = Number(value.slice(0, 4));
        const now = new Date();
        return isValidDate(value) && year >= 1920 && new Date(`${value}T00:00:00Z`) < now;
      }, "La date de naissance doit être antérieure à aujourd'hui."),
    wilaya: z
      .string()
      .refine((value) => WILAYAS.some((wilaya) => wilaya.name === value), "Sélectionnez votre wilaya de résidence."),
    bloodType: z.enum(BLOOD_TYPES, "Sélectionnez votre rhésus sanguin."),
    retirementDate: z
      .string()
      .refine(isValidDate, "Renseignez une date de départ à la retraite valide.")
      .refine((value) => {
        if (!isValidDate(value)) return false;
        const date = new Date(`${value}T00:00:00Z`);
        return date <= new Date() && date.getUTCFullYear() >= 1950;
      }, "La date de départ à la retraite doit être une date passée valide."),
    socialSecurityNumber: z
      .string()
      .trim()
      .transform((value) => value.replace(/[\s.-]/g, ""))
      .refine((value) => /^\d{9,15}$/.test(value), "Le numéro SS doit comporter entre 9 et 15 chiffres."),
    cnrNumber: z
      .string()
      .trim()
      .transform((value) => value.replace(/\s/g, "").toUpperCase())
      .refine(
        (value) => /^[A-Z0-9/-]{5,20}$/.test(value),
        "Le numéro CNR doit comporter entre 5 et 20 caractères (lettres, chiffres, / ou -).",
      ),
    mobile: z
      .string()
      .trim()
      .transform((value) => value.replace(/[\s.-]/g, ""))
      .refine((value) => /^0[5-7]\d{8}$/.test(value), "Numéro mobile invalide (ex : 0550123456)."),
    email: z
      .string()
      .trim()
      .toLowerCase()
      .max(120, "L'adresse e-mail est trop longue.")
      .refine((value) => EMAIL_REGEX.test(value), "Adresse e-mail invalide."),
    photoData: dataUrl(["data:image/jpeg;base64,", "data:image/png;base64,", "data:image/webp;base64,"])
      .refine((value) => value.length <= MAX_PHOTO_CHARS, "La photo ne doit pas dépasser 1 Mo.")
      .optional(),
    attachmentName: z.string().trim().max(160).optional().or(z.literal("")),
    attachmentType: z.string().trim().max(120).optional().or(z.literal("")),
    attachmentData: dataUrl([
      "data:image/jpeg;base64,",
      "data:image/png;base64,",
      "data:image/webp;base64,",
      "data:application/pdf;base64,",
    ])
      .refine((value) => value.length <= MAX_ATTACHMENT_CHARS, "La pièce jointe ne doit pas dépasser 2 Mo.")
      .optional(),
    consent: z.literal(true, "Vous devez accepter l'utilisation de vos données."),
  })
  .refine(
    (data) =>
      isValidDate(data.birthDate) &&
      isValidDate(data.retirementDate) &&
      new Date(`${data.retirementDate}T00:00:00Z`) > new Date(`${data.birthDate}T00:00:00Z`),
    {
      message: "La date de départ à la retraite doit être postérieure à la date de naissance.",
      path: ["retirementDate"],
    },
  );

export type MembershipInput = z.infer<typeof membershipSchema>;

export type MembershipDraft = {
  lastName: string;
  firstName: string;
  birthDate: string;
  wilaya: string;
  bloodType: string;
  retirementDate: string;
  socialSecurityNumber: string;
  cnrNumber: string;
  mobile: string;
  email: string;
  photoData?: string;
  attachmentName?: string;
  attachmentType?: string;
  attachmentData?: string;
  consent: boolean;
};

export function fieldErrors(error: z.ZodError): Record<string, string> {
  const result: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = issue.path[0];
    if (typeof key === "string" && !result[key]) {
      result[key] = issue.message;
    }
  }
  return result;
}
