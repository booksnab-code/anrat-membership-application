import { ASSOCIATION } from "./constants";

export type ForwardStatus = "non_configure" | "transmise" | "echec";

export type ForwardResult = {
  status: ForwardStatus;
  channel: string | null;
  error: string | null;
  configured: boolean;
  attemptedChannels: string[];
};

export type ForwardPayload = {
  reference: string;
  lastName: string;
  firstName: string;
  birthDate: string;
  wilaya: string;
  bloodType: string;
  retirementDate: string;
  socialSecurityNumber: string;
  cnrNumber: string;
  mobile: string;
  email: string;
  photoData?: string | null;
  attachmentName?: string | null;
  attachmentData?: string | null;
  submittedAt: string;
};

export type IntegrationConfig = {
  formUrl: string | null;
  formFieldMap: Record<string, string>;
  sheetWebhookUrl: string | null;
  mailApiKey: string | null;
  mailFrom: string;
  mailTo: string;
};

export function getIntegrationConfig(): IntegrationConfig {
  let formFieldMap: Record<string, string> = {};
  const rawMap = process.env.GOOGLE_FORM_FIELD_MAP;
  if (rawMap) {
    try {
      const parsed: unknown = JSON.parse(rawMap);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        formFieldMap = Object.fromEntries(
          Object.entries(parsed as Record<string, unknown>)
            .filter(([, value]) => typeof value === "string")
            .map(([key, value]) => [key, String(value)]),
        );
      }
    } catch {
      formFieldMap = {};
    }
  }

  return {
    formUrl: process.env.GOOGLE_FORM_RESPONSE_URL?.trim() || null,
    formFieldMap,
    sheetWebhookUrl: process.env.GOOGLE_SHEETS_WEBHOOK_URL?.trim() || null,
    mailApiKey: process.env.RESEND_API_KEY?.trim() || null,
    mailFrom: process.env.MAIL_FROM?.trim() || "ANRAT <onboarding@resend.dev>",
    mailTo: process.env.AT_ASSOCIATION_EMAIL?.trim() || ASSOCIATION.email,
  };
}

export function integrationSummary() {
  const config = getIntegrationConfig();
  return {
    googleForm: Boolean(config.formUrl && Object.keys(config.formFieldMap).length > 0),
    googleDrive: Boolean(config.sheetWebhookUrl),
    email: Boolean(config.mailApiKey),
    configured: Boolean(
      (config.formUrl && Object.keys(config.formFieldMap).length > 0) ||
        config.sheetWebhookUrl ||
        config.mailApiKey,
    ),
    associationEmail: config.mailTo,
    formUrl: config.formUrl,
    driveConnected: Boolean(config.sheetWebhookUrl),
  };
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function summaryRows(payload: ForwardPayload): Array<[string, string]> {
  return [
    ["Référence", payload.reference],
    ["Nom", payload.lastName],
    ["Prénom", payload.firstName],
    ["Date de naissance", payload.birthDate],
    ["Wilaya de résidence", payload.wilaya],
    ["Rhésus sanguin", payload.bloodType],
    ["Date départ à la retraite", payload.retirementDate],
    ["N° sécurité sociale", payload.socialSecurityNumber],
    ["N° CNR", payload.cnrNumber],
    ["Mobile", payload.mobile],
    ["E-mail", payload.email],
    ["Pièce jointe", payload.attachmentName || "Aucune"],
    ["Photo", payload.photoData ? "Fournie (à récupérer dans l'espace adhérent)" : "Non fournie"],
    ["Transmis le", payload.submittedAt],
  ];
}

async function pushToSheet(webhookUrl: string, payload: ForwardPayload): Promise<void> {
  const body: Record<string, unknown> = {
    ...payload,
    form: "Adhésion ANRAT",
    association: "ANRAT",
    destination: ASSOCIATION.email,
    photoData: payload.photoData ? "présente" : "",
    attachmentData: payload.attachmentData ? "présente" : "",
  };

  const response = await fetch(webhookUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    cache: "no-store",
    signal: AbortSignal.timeout(9000),
  });

  if (!response.ok) {
    throw new Error(`Webhook Drive/Sheets : HTTP ${response.status}`);
  }
}

async function pushToGoogleForm(
  formUrl: string,
  fieldMap: Record<string, string>,
  payload: ForwardPayload,
): Promise<void> {
  const params = new URLSearchParams();
  const flat: Record<string, string> = {
    reference: payload.reference,
    lastName: payload.lastName,
    firstName: payload.firstName,
    birthDate: payload.birthDate,
    wilaya: payload.wilaya,
    bloodType: payload.bloodType,
    retirementDate: payload.retirementDate,
    socialSecurityNumber: payload.socialSecurityNumber,
    cnrNumber: payload.cnrNumber,
    mobile: payload.mobile,
    email: payload.email,
    attachmentName: payload.attachmentName || "",
  };

  let mapped = 0;
  for (const [key, value] of Object.entries(flat)) {
    const entry = fieldMap[key];
    if (entry) {
      params.append(entry, value);
      mapped += 1;
    }
  }

  if (mapped === 0) {
    throw new Error("Aucun champ Google Forms configuré.");
  }

  const response = await fetch(formUrl, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString(),
    cache: "no-store",
    redirect: "manual",
    signal: AbortSignal.timeout(9000),
  });

  if (response.status >= 400) {
    throw new Error(`Google Forms : HTTP ${response.status}`);
  }
}

async function sendEmail(
  apiKey: string,
  from: string,
  to: string,
  payload: ForwardPayload,
): Promise<void> {
  const rows = summaryRows(payload)
    .map(
      ([label, value]) =>
        `<tr><td style="padding:8px 12px;border:1px solid #dbe4ef;color:#5b6b7c;font-size:13px">${escapeHtml(
          label,
        )}</td><td style="padding:8px 12px;border:1px solid #dbe4ef;font-weight:600;color:#0b2b45">${escapeHtml(
          value,
        )}</td></tr>`,
    )
    .join("");

  const html = `
    <div style="font-family:Arial,Helvetica,sans-serif;background:#f3f7fb;padding:24px">
      <div style="max-width:640px;margin:0 auto;background:#fff;border-radius:16px;overflow:hidden;border:1px solid #dbe4ef">
        <div style="background:linear-gradient(120deg,#0b4f9e,#0c7a4d);padding:22px 26px;color:#fff">
          <div style="font-size:12px;letter-spacing:2px;text-transform:uppercase;opacity:.85">ANRAT · Algérie Télécom</div>
          <div style="font-size:21px;font-weight:700;margin-top:6px">Nouvelle demande d'adhésion</div>
          <div style="font-size:13px;opacity:.9;margin-top:4px">Référence ${escapeHtml(payload.reference)}</div>
        </div>
        <div style="padding:22px 26px">
          <p style="font-size:14px;color:#33475b;margin:0 0 16px">
            Une nouvelle demande d'adhésion a été déposée depuis le formulaire en ligne ANRAT.
          </p>
          <table style="border-collapse:collapse;width:100%">${rows}</table>
          <p style="font-size:12px;color:#7a8b9c;margin:18px 0 0">
            Formulaire ANRAT — destinataire : ${escapeHtml(to)}
          </p>
        </div>
      </div>
    </div>`;

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from,
      to: [to],
      subject: `[ANRAT] Nouvelle adhésion — ${payload.lastName.toUpperCase()} ${payload.firstName} (${payload.reference})`,
      html,
    }),
    cache: "no-store",
    signal: AbortSignal.timeout(9000),
  });

  if (!response.ok) {
    throw new Error(`Service e-mail : HTTP ${response.status}`);
  }
}

/**
 * Transmet la demande vers le Drive / Google Forms de l'association.
 * L'application enregistre toujours la demande en base : la transmission est
 * un canal complémentaire, activé par variables d'environnement.
 */
export async function forwardMembership(payload: ForwardPayload): Promise<ForwardResult> {
  const config = getIntegrationConfig();
  const errors: string[] = [];
  const attemptedChannels: string[] = [];

  if (config.sheetWebhookUrl) {
    attemptedChannels.push("Drive / Google Sheets");
    try {
      await pushToSheet(config.sheetWebhookUrl, payload);
      return {
        status: "transmise",
        channel: "Drive / Google Sheets",
        error: null,
        configured: true,
        attemptedChannels,
      };
    } catch (error) {
      errors.push(error instanceof Error ? error.message : "Erreur Drive inconnue");
    }
  }

  if (config.formUrl && Object.keys(config.formFieldMap).length > 0) {
    attemptedChannels.push("Google Forms");
    try {
      await pushToGoogleForm(config.formUrl, config.formFieldMap, payload);
      return {
        status: "transmise",
        channel: "Google Forms",
        error: null,
        configured: true,
        attemptedChannels,
      };
    } catch (error) {
      errors.push(error instanceof Error ? error.message : "Erreur Google Forms inconnue");
    }
  }

  if (config.mailApiKey) {
    attemptedChannels.push(`E-mail ${config.mailTo}`);
    try {
      await sendEmail(config.mailApiKey, config.mailFrom, config.mailTo, payload);
      return {
        status: "transmise",
        channel: `E-mail ${config.mailTo}`,
        error: null,
        configured: true,
        attemptedChannels,
      };
    } catch (error) {
      errors.push(error instanceof Error ? error.message : "Erreur e-mail inconnue");
    }
  }

  if (attemptedChannels.length === 0) {
    return {
      status: "non_configure",
      channel: null,
      error: null,
      configured: false,
      attemptedChannels,
    };
  }

  return {
    status: "echec",
    channel: attemptedChannels[attemptedChannels.length - 1] ?? null,
    error: errors.join(" | ").slice(0, 500) || "Transmission impossible",
    configured: true,
    attemptedChannels,
  };
}

export function buildMailtoLink(payload: ForwardPayload): string {
  const lines = summaryRows(payload)
    .filter(([label]) => label !== "Photo")
    .map(([label, value]) => `${label} : ${value}`);
  lines.push("", "Ces informations sont destinées à la confection de la carte d'adhésion ANRAT.");
  const subject = `Adhésion ANRAT — ${payload.lastName.toUpperCase()} ${payload.firstName} (${payload.reference})`;
  return `mailto:${ASSOCIATION.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(
    lines.join("\n"),
  )}`;
}
