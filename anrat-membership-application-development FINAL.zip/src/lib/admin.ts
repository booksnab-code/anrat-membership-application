import { createHash, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";

export const ADMIN_COOKIE = "anrat_admin_session";

function adminPassword(): string {
  return process.env.ADMIN_PASSWORD?.trim() || "ANRAT2022";
}

function hash(value: string): string {
  return createHash("sha256").update(`${value}::anrat-admin-v1`).digest("hex");
}

export function sessionToken(): string {
  return hash(adminPassword());
}

export function isValidPassword(input: string): boolean {
  const expected = Buffer.from(hash(adminPassword()), "utf8");
  const provided = Buffer.from(hash(input), "utf8");
  if (expected.length !== provided.length) return false;
  return timingSafeEqual(expected, provided);
}

export function isDefaultPassword(): boolean {
  return !process.env.ADMIN_PASSWORD?.trim();
}

export async function isAdminAuthenticated(): Promise<boolean> {
  const store = await cookies();
  const value = store.get(ADMIN_COOKIE)?.value;
  return Boolean(value) && value === sessionToken();
}

export function unauthorized(): Response {
  return Response.json({ ok: false, error: "Accès réservé à l'administration ANRAT." }, { status: 401 });
}
