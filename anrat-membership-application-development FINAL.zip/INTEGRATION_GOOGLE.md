# ANRAT — transmission des demandes vers Google Forms / Drive

L'application enregistre **toutes** les demandes d'adhésion dans PostgreSQL (espace
association `/admin`). En complément, elle transmet automatiquement chaque demande vers
le canal de l'association (`atassociation2022@gmail.com`). Trois canaux sont pris en
charge ; le premier configuré est utilisé, avec repli sur le suivant en cas d'échec :

1. **Google Sheets / Drive** via un Web App Apps Script (`GOOGLE_SHEETS_WEBHOOK_URL`)
2. **Google Forms** (`GOOGLE_FORM_RESPONSE_URL` + `GOOGLE_FORM_FIELD_MAP`)
3. **E-mail** via Resend (`RESEND_API_KEY`) vers `AT_ASSOCIATION_EMAIL`

Si aucun canal n'est configuré, la demande reste enregistrée en base avec le statut
`non_configure` et l'adhérent peut la transmettre en un clic par e-mail
(`mailto:atassociation2022@gmail.com`). L'écran d'accusé de réception indique toujours
la référence de la demande.

## Option 1 — Google Drive / Sheets (recommandée)

1. Créez une feuille de calcul dans le Drive du compte `atassociation2022@gmail.com`.
2. Extensions → Apps Script, collez ce script puis déployez-le
   (Déployer → Nouveau déploiement → Application Web, accès « Tout le monde ») :

```javascript
const SHEET_ID = "ID_DE_LA_FEUILLE";
const TOKEN = "un-secret-long-et-aleatoire"; // doit correspondre au segment ?token= de l'URL

function doPost(e) {
  const body = JSON.parse(e.postData.contents);
  const sheet = SpreadsheetApp.openById(SHEET_ID).getSheets()[0];
  if (sheet.getLastRow() === 0) {
    sheet.appendRow([
      "Date", "Référence", "Nom", "Prénom", "Naissance", "Wilaya", "Rhésus",
      "Départ retraite", "N° SS", "N° CNR", "Mobile", "E-mail", "Pièce jointe",
    ]);
  }
  sheet.appendRow([
    new Date(), body.reference, body.lastName, body.firstName, body.birthDate,
    body.wilaya, body.bloodType, body.retirementDate, body.socialSecurityNumber,
    body.cnrNumber, body.mobile, body.email, body.attachmentName || "",
  ]);
  return ContentService.createTextOutput(JSON.stringify({ ok: true }))
    .setMimeType(ContentService.MimeType.JSON);
}
```

3. Renseignez `GOOGLE_SHEETS_WEBHOOK_URL` avec l'URL de déploiement
   (`.../exec?token=un-secret-long-et-aleatoire`).

La photo et la pièce jointe ne sont pas envoyées par ce canal : elles restent
disponibles dans l'espace association (`/admin` → détail de la demande).

## Option 2 — Google Forms

1. Créez un formulaire Google avec un champ court par information.
2. Menu ⋮ → « Obtenir le lien prérempli », remplissez chaque champ puis cliquez sur
   « Obtenir le lien ». L'URL contient `entry.XXXXXX` pour chaque champ.
3. Renseignez :
   - `GOOGLE_FORM_RESPONSE_URL` : remplacez `/viewform` par `/formResponse`
   - `GOOGLE_FORM_FIELD_MAP` : JSON des correspondances, par exemple
     `{"lastName":"entry.111","firstName":"entry.222", ...}`

Clés reconnues : `reference`, `lastName`, `firstName`, `birthDate`, `wilaya`,
`bloodType`, `retirementDate`, `socialSecurityNumber`, `cnrNumber`, `mobile`, `email`,
`attachmentName`.

## Option 3 — Notification e-mail

Créez une clé sur [resend.com](https://resend.com), puis définissez
`RESEND_API_KEY` (et éventuellement `MAIL_FROM`, `AT_ASSOCIATION_EMAIL`).
Un e-mail récapitulatif HTML est envoyé à l'association à chaque demande.

## Espace association

`/admin` — mot de passe `ADMIN_PASSWORD` (par défaut `ANRAT2022`, à modifier en
production) :

- statistiques et recherche (nom, référence, mobile, wilaya)
- consultation du détail, de la photo et des pièces jointes
- validation / rejet / remise en attente + note interne
- export CSV compatible Excel (séparateur `;`, BOM UTF-8)
